#!/usr/bin/env python3
"""Full support only; preserves the stopped s/p experiment unchanged."""
from pathlib import Path
import importlib.util,sys,os,signal,datetime,math
ROOT=Path(__file__).resolve().parents[3]
ORIGINAL=ROOT/'poams-review/artifacts/molecular-reentry-2026-09-16/preflight.py'
s=importlib.util.spec_from_file_location('original_preflight',ORIGINAL)
m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
OLDREG=m.REG
m.HERE=Path(__file__).resolve().parent
m.REG=ROOT/'poams-review/reviews/molecular-reentry-full-space-registration-2026-09-16.md'
m.CONFIGS={k:v for k,v in m.CONFIGS.items() if k!='T-sp'}

def run():
    m.require(not (m.HERE/'freeze.json').exists(),'never overwrite prior full run')
    files=[Path(__file__),ORIGINAL,m.REG,OLDREG,m.PROBE,m.OLD]
    for src in m.SOURCES.values():files.extend([src['path'],src['statepath']])
    freeze={str(p.relative_to(ROOT)):m.digest(p) for p in files}
    m.dump('freeze.json',{'time':datetime.datetime.now().astimezone().isoformat(),
                         'files':freeze,'configs':m.CONFIGS,'geometry':m.Q.tolist()})
    m.dump('status.json',{'state':'running','pid':os.getpid(),'wall_cap_seconds':1800})
    signal.signal(signal.SIGALRM,lambda *args: (_ for _ in ()).throw(TimeoutError('registered wall cap')))
    signal.alarm(1800)
    controls={'atomic_imports':m.atomic_controls(),'pair_assembly':m.pair.controls(),
              'planned_metrics':{label:m.metric(m.make(label,m.Q))[2] for label in m.CONFIGS}}
    m.dump('controls.json',controls);m.emit('CONTROLS_PASS')
    points=[]
    for label in m.CONFIGS:
        for off in (0.,-.5,.5,-1.,1.):
            points.append(m.one(label,off,gradients=label=='T' and off==0))
    slopes=m.summary(points);center={p['label']:p for p in points if p['offset_degree']==0}
    for off in (0.,-.5,.5,-1.,1.):
        pp={p['label']:p for p in points if p['offset_degree']==off}
        m.require(pp['T-tail']['RHF']<=pp['T']['RHF']+2e-6,'diffuse variational gate')
    errors={a:center['T']['analytic_angular_'+a]-slopes['T'][a]['richardson_slope'] for a in ('RHF','MP2')}
    m.require(max(abs(v) for v in errors.values())<2e-5,'analytic gradient mismatch')
    theta=.47;rot=m.np.array([[math.cos(theta),0,math.sin(theta)],[0,1,0],[-math.sin(theta),0,math.cos(theta)]])
    moved=[(s,tuple(m.np.array(p)@rot+[.31,-.22,.18])) for s,p in m.atoms(m.Q)]
    rotated=m.one('T',0,override=[moved[i] for i in [2,0,1]],tag='T-rigid-permuted')
    shifted=m.one('T',0,shift=100.,tag='T-energy-shift')
    checks={'analytic_minus_finite_difference':errors,
            'rigid_permutation_errors':{a:rotated[a]-center['T'][a] for a in ('RHF','MP2')},
            'energy_zero_errors':{a:shifted[a]-1000-center['T'][a] for a in ('RHF','MP2')}}
    m.require(max(abs(v) for k in ('rigid_permutation_errors','energy_zero_errors') for v in checks[k].values())<1e-7,'covariance or energy-zero gate')
    m.dump('molecular-controls.json',checks)
    frags=[m.fragment(i,g) for g in (False,True) for i in range(3)]
    bsse={a:sum(r[a] for r in frags if not r['ghosts'])-sum(r[a] for r in frags if r['ghosts']) for a in ('RHF_or_ROHF','MP2')}
    result={'status':'bounded_full_space_reference_complete','main_points':len(points),
            'slopes':slopes,'controls':checks,'basis_superposition_own_minus_ghost':bsse,
            'limitations':['The s/p-only attempt failed occupied-seed preservation and remains stopped.',
            'Full-space reference, not native closure, angular-only decomposition or equilibrium validation.',
            'MP2 is not UCCSD(T); no higher-order error bound.',
            'O axial atomic cardinal change 1.018046%; finite-basis removal limits retained.',
            'Ghost-fragment orbital orientation not certified: BSSE is diagnostic only.']}
    m.require(all(m.digest(ROOT/p)==h for p,h in freeze.items()),'source changed during run')
    m.dump('result.json',result);m.dump('status.json',{'state':'completed','pid':os.getpid()})
    m.emit('COMPLETE',main_points=len(points),slopes=slopes,BSSE=bsse)

if __name__=='__main__':
    try:run()
    except Exception as exc:
        m.dump('status.json',{'state':'stopped_failure','pid':os.getpid(),'error':repr(exc)})
        m.emit('STOPPED_FAILURE',error=repr(exc));raise
