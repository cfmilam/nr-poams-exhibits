"""Independent result consumer: custody, finite differences, state identities."""
from pathlib import Path
from decimal import Decimal,localcontext
import json,hashlib,math
import numpy as np
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
checks=[]
def check(name,passed):
    checks.append({'name':name,'pass':bool(passed)})
    if not passed:raise AssertionError(name)
def read(name):return json.loads((HERE/name).read_text())
f=read('freeze.json')
for name,expected in f['files'].items():
    check('custody '+name,hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==expected)
check('worker completed',read('status.json')['state']=='completed')
r=read('result.json');rate=6.579683920428908
derived={}
for label,n in [('D',45),('T',105),('T-tail',137)]:
    rows={v:read(f'{label}-{v:+.1f}.json') for v in [0.,-.5,.5,-1.,1.]}
    for off,p in rows.items():
        check(f'{label} {off} chart',p['nao']==n and p['metric']['rank']==n)
        check(f'{label} {off} stationarity',p['gradient_norm']<1e-7)
        check(f'{label} {off} support',p['metric']['seed_containment_defect']<1e-9)
        check(f'{label} {off} pair',abs(p['pair_check']['library_difference'])<1e-8)
        check(f'{label} {off} energy accounting',abs(p['MP2']-p['RHF']-p['correlation'])<1e-11)
    z=np.load(HERE/f'{label}-center.npz',allow_pickle=False)
    check(label+' density entry count',abs(np.einsum('ij,ji',z['density'],z['overlap'])-10)<1e-9)
    check(label+' density idempotency',np.linalg.norm(z['density']@z['overlap']@z['density']-2*z['density'])<1e-8)
    for meth in ('RHF','MP2'):
        slopes=[]
        with localcontext() as ctx:
            ctx.prec=45
            for d in [.5,1.]:
                h=Decimal(str(math.radians(d)))
                slope=(Decimal(str(rows[d][meth]))-Decimal(str(rows[-d][meth])))/(2*h)
                slopes.append(slope)
                check(f'{label} {meth} decimal stencil {d}',abs(float(slope)-r['slopes'][label][meth][str(d)]['slope'])<2e-11)
            deriv=float((4*slopes[0]-slopes[1])/3)
            check(f'{label} {meth} derivative',abs(deriv-r['slopes'][label][meth]['richardson_slope'])<2e-11)
            derived.setdefault(label,{})[meth]={'slope_Estar_per_rad':deriv,'slope_PHz_per_rad':deriv*rate}
for key,vals in r['controls'].items():
    limit=2e-5 if key=='analytic_minus_finite_difference' else 1e-7
    check(key,max(abs(v) for v in vals.values())<limit)
for off in [0.,-.5,.5,-1.,1.]:
    check(f'nested variational {off}',read(f'T-tail-{off:+.1f}.json')['RHF']<=read(f'T-{off:+.1f}.json')['RHF']+2e-6)
first=ROOT/'poams-review/artifacts/molecular-reentry-2026-09-16'
old=json.loads((first/'status.json').read_text())
check('earlier seed failure retained',old['state']=='stopped_failure' and 'occupied atomic direction excluded' in old['error'])
check('no invalid sp result',not list(first.glob('T-sp-*.json')))
effects={}
for label in ('D','T','T-tail'):
    s=r['slopes'][label]
    effect=s['MP2']['richardson_slope']-s['RHF']['richardson_slope']
    discrepancy=s['MP2']['slope_step_discrepancy']+s['RHF']['slope_step_discrepancy']
    effects[label]={'correlation_slope_change':effect,'conservative_stencil_budget':10*discrepancy,
                    'resolved':abs(effect)>max(1e-5,10*discrepancy)}
check('same-space correlation slopes resolved',all(v['resolved'] for v in effects.values()))
output={'pass':True,'check_count':len(checks),'checks':checks,'derived':derived,'effects':effects,
        'scope':'independent consumer audit, not physical-equilibrium validation'}
(HERE/'audit.json').write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps({k:v for k,v in output.items() if k!='checks'},indent=2))
