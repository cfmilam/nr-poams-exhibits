#!/usr/bin/env python3
"""Bounded, non-optimizing water reference bridge. See frozen registration."""
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS'):
    os.environ[key]='1'
from pathlib import Path
import datetime, hashlib, importlib.util, json, math, signal, sys, time
import numpy as np
from scipy.linalg import eigh, null_space, qr
from pyscf import gto, scf, mp, lib

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
AT=ROOT/'poams-review/artifacts/cno-correlated-2026-09-16'
REG=ROOT/'poams-review/reviews/molecular-reentry-registration-2026-09-16.md'
OLD=ROOT/'poams-review/artifacts/water-v1-postfailure-2026-09-11/fixed-book.npz'
PROBE=ROOT/'poams-review/artifacts/water-readiness-v2-2026-09-11/configuration_probe.py'
spec=importlib.util.spec_from_file_location('pair_probe',PROBE)
pair=importlib.util.module_from_spec(spec);spec.loader.exec_module(pair)
A_ANG=0.5291772105467402
lib.num_threads(1)

def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(name,obj):
    p=HERE/name;t=p.with_suffix(p.suffix+'.tmp')
    t.write_text(json.dumps(obj,indent=2,allow_nan=False)+'\n');t.replace(p)
def emit(event,**kw):
    row={'time':datetime.datetime.now().astimezone().isoformat(),'event':event,**kw}
    print(json.dumps(row,allow_nan=False),flush=True)
def require(ok,why):
    if not ok:raise ArithmeticError(why)
def load_atom(el,level,aug):
    folder=AT/('third-diffuse/records' if aug==3 else 'production/records')
    paths=list(folder.glob(f'{el}-q0-L{level}-a{aug}-parallel-F+0.000000-*.json'))
    paths=[p for p in paths if not p.name.endswith('.energy.json')]
    require(len(paths)==1,'atomic source ambiguity')
    p=paths[0];r=json.loads(p.read_text());st=p.parent/r['state_file']
    require(r['complete'] and digest(st)==r['state_sha256'],'atomic state custody')
    z=np.load(st,allow_pickle=False)
    return {'record':r,'path':p,'statepath':st,'state':{k:z[k] for k in z.files}}

SOURCES={(el,lev,aug):load_atom(el,lev,aug) for el,lev,aug in
         [('H',2,1),('O',2,1),('H',3,1),('O',3,1),('O',3,3)]}
CONFIGS={'D':(2,1,False),'T-sp':(3,1,True),'T':(3,1,False),'T-tail':(3,3,False)}
Q=np.load(OLD,allow_pickle=False)['geometry'].copy()

def atoms(q):
    a,b,t=q
    return [('O',(0.,0.,0.)),('H',(a/A_ANG,0.,0.)),
            ('H',(b*math.cos(t)/A_ANG,b*math.sin(t)/A_ANG,0.))]
def basis(label):
    lev,aug,sp=CONFIGS[label]
    return {el:[s for s in SOURCES[(el,lev,aug if el=='O' else 1)]['record']['basis']
                if not sp or s[0]<=1] for el in ('O','H')}
def make(label,q,atom_override=None,spin=0):
    return gto.M(atom=atom_override or atoms(q),basis=basis(label),unit='Bohr',
                 spin=spin,symmetry=False,verbose=0,max_memory=3000)

def metric(mol):
    s=mol.intor_symmetric('int1e_ovlp');d=1/np.sqrt(np.diag(s))
    v,u=eigh(s*d[:,None]*d[None,:]);n=len(s)
    budget=64*n*np.finfo(float).eps*max(1.,v[-1])
    require(v[0]>budget,'unresolved full finite support')
    x=d[:,None]*u/np.sqrt(v)
    vv,uu=eigh((x.T@s@x+x.T@s.T@x)*.5)
    x=x@((uu/np.sqrt(vv))@uu.T)
    defect=float(np.linalg.norm(x.T@s@x-np.eye(n),2))
    require(defect<1e-8,'full metric defect')
    return s,x,{'rank':n,'smallest_normalized_root':float(v[0]),'budget':float(budget),
                'condition':float(v[-1]/v[0]),'metric_defect':defect,
                'scope':'whole supplied finite support, not minimality or basis completeness'}

def atomic_seed(mol,label):
    lev,aug,sp=CONFIGS[label];dm=np.zeros((mol.nao,mol.nao));seeds=[]
    for i,el in enumerate(('O','H','H')):
        src=SOURCES[(el,lev,aug if el=='O' else 1)]
        st=src['state'];c=st['mo_coeff'];oc=st['mo_occ']
        am=gto.M(atom=el,basis=src['record']['basis'],spin=2 if el=='O' else 1,verbose=0)
        mask=np.concatenate([np.full(am.ao_loc_nr()[j+1]-am.ao_loc_nr()[j],
                   not sp or am.bas_angular(j)<=1) for j in range(am.nbas)])
        start,end=mol.aoslice_by_atom()[i,2:]
        for spin in range(2):
            occ=c[spin][:,oc[spin]>0]
            require(np.linalg.norm(occ[~mask])<1e-9,'occupied atomic direction excluded')
            emb=np.zeros((mol.nao,occ.shape[1]));emb[start:end]=occ[mask]
            dm+=emb@emb.T;seeds.append(emb)
    return dm,np.column_stack(seeds)

def configure(mol,tag):
    s,x,cert=metric(mol);mf=scf.RHF(mol)
    mf.verbose=0;mf.max_memory=3000;mf.max_cycle=150
    mf.conv_tol=1e-12;mf.conv_tol_grad=1e-8
    mf.chkfile=str(HERE/(tag+'.chk'));mf._eri=mol.intor('int2e',aosym='s8')
    def eig(f,overlap,**kw):
        h=x.T@f@x;ev,ec=eigh((h+h.T)*.5);return ev,x@ec
    mf.eig=eig
    return mf,s,x,cert

def one(label,offset,gradients=False,override=None,shift=0.,tag=None):
    q=Q.copy();q[2]+=math.radians(offset);mol=make(label,q,override)
    tag=tag or f'{label}-{offset:+.1f}';start=time.monotonic()
    mf,s,x,cert=configure(mol,tag)
    dm,seed=atomic_seed(mol,label) if override is None else (None,None)
    if shift:
        h=mf.get_hcore()+shift*s;mf.get_hcore=lambda *args:h
    if seed is not None:
        defect=float(np.linalg.norm(seed-x@(x.T@s@seed)))
        cert['seed_containment_defect']=defect
        require(defect<1e-9,'seed containment')
        require(abs(np.einsum('ij,ji',dm,s)-10)<1e-8,'seed entry count')
    e=float(mf.kernel(dm0=dm));g=float(np.linalg.norm(mf.get_grad(mf.mo_coeff,mf.mo_occ)))
    require(mf.converged and g<1e-7,'RHF not stationary')
    cert['final_orbital_metric_defect']=float(np.linalg.norm(mf.mo_coeff.T@s@mf.mo_coeff-np.eye(mol.nao),2))
    require(cert['final_orbital_metric_defect']<1e-8,'final orbital metric')
    p=mp.MP2(mf);p.max_memory=3000;eris=p.ao2mo();corr,_=p.kernel(eris=eris,with_t2=False)
    no=p.nocc;nv=p.nmo-no
    gg=np.asarray(eris.ovov).reshape(no,nv,no,nv).transpose(0,2,1,3)
    check=pair.cofactor_second_order(gg,mf.mo_energy[:no],mf.mo_energy[no:])
    check['library_difference']=float(check['energy']-corr)
    require(abs(check['library_difference'])<1e-8,'cofactor contraction mismatch')
    require(check['perturbative_readiness'],'perturbative diagnostic failed')
    out={'label':label,'offset_degree':offset,'geometry':q.tolist(),'nao':mol.nao,
         'RHF':e,'MP2':float(e+corr),'correlation':float(corr),'gradient_norm':g,
         'metric':cert,'pair_check':check}
    if gradients:
        xyz_deriv=np.array([-q[1]*math.sin(q[2])/A_ANG,q[1]*math.cos(q[2])/A_ANG,0.])
        out['analytic_angular_RHF']=float(mf.nuc_grad_method().kernel()[2]@xyz_deriv)
        out['analytic_angular_MP2']=float(p.nuc_grad_method().kernel()[2]@xyz_deriv)
    out['seconds']=time.monotonic()-start
    dump(tag+'.json',out)
    if offset==0 and not override and not shift:
        np.savez_compressed(HERE/(label+'-center.npz'),overlap=s,x=x,
                            mo_coeff=mf.mo_coeff,mo_occ=mf.mo_occ,
                            density=mf.make_rdm1(),mo_energy=mf.mo_energy)
    emit('POINT',label=tag,nao=mol.nao,RHF=e,MP2=out['MP2'],seconds=out['seconds'])
    return out

def atomic_controls():
    out=[]
    for key,src in SOURCES.items():
        el,lev,aug=key;st=src['state'];r=src['record']
        mol=gto.M(atom=el,basis=r['basis'],spin=1 if el=='H' else 2,verbose=0)
        s=mol.intor_symmetric('int1e_ovlp')
        dif=float(np.max(abs(s-st['overlap'])))
        defs=[float(np.linalg.norm(c.T@s@c-np.eye(mol.nao),2)) for c in st['mo_coeff']]
        require(dif<1e-12 and max(defs)<1e-8,'atomic import normalization')
        out.append({'symbol':el,'level':lev,'augmentation':aug,'nao':mol.nao,
                    'overlap_difference':dif,'orbital_metric_defects':defs,
                    'source':str(src['path'].relative_to(ROOT)),'sha256':digest(src['path'])})
    return out

def complement():
    full=make('T',Q);small=make('T-sp',Q)
    mask=np.concatenate([np.full(full.ao_loc_nr()[j+1]-full.ao_loc_nr()[j],
                                full.bas_angular(j)<=1) for j in range(full.nbas)])
    emb=np.eye(full.nao)[:,mask]
    b=np.load(HERE/'T-sp-center.npz',allow_pickle=False)
    a=np.load(HERE/'T-center.npz',allow_pickle=False)
    require(np.linalg.norm(emb.T@a['overlap']@emb-b['overlap'])<1e-11,'non-nested angular support')
    mf=scf.RHF(full);dm=emb@b['density']@emb.T
    f=mf.get_hcore()+mf.get_veff(dm=dm)
    xb=a['x'];q=qr(xb.T@a['overlap']@emb@b['x'],mode='economic')[0]
    c=null_space(q.T)
    occ=xb.T@a['overlap']@emb@b['mo_coeff'][:,b['mo_occ']>0]
    leak=c.T@(xb.T@f@xb)@occ
    return {'new_directions':c.shape[1],'coupling_norm':float(np.linalg.norm(leak)),
            'coupling_singular_values':np.linalg.svd(leak,compute_uv=False).tolist()}

def fragment(index,ghost):
    geo=atoms(Q);el=geo[index][0]
    aa=[(s if i==index else 'ghost-'+s,xyz) for i,(s,xyz) in enumerate(geo)] if ghost else [geo[index]]
    mol=make('T',Q,aa,spin=2 if el=='O' else 1)
    s,x,cert=metric(mol);mf=scf.ROHF(mol)
    mf.conv_tol=1e-12;mf.conv_tol_grad=1e-8;mf.max_cycle=150;mf.max_memory=3000
    e=float(mf.kernel());require(mf.converged,'fragment SCF')
    uhf=mf.to_uhf();uhf.mo_energy,uhf.mo_coeff=uhf.canonicalize(uhf.mo_coeff,uhf.mo_occ)
    p=mp.UMP2(uhf);p.max_memory=3000;ec,_=p.kernel(with_t2=False)
    out={'index':index,'element':el,'ghosts':ghost,'RHF_or_ROHF':e,
         'MP2':float(e+ec),'correlation':float(ec),'spin_square':float(uhf.spin_square()[0]),
         'metric':cert,'reference_gradient':float(np.linalg.norm(mf.get_grad(mf.mo_coeff,mf.mo_occ))),
         'state_grade':'spin sector only; ghost-field orbital orientation is not certified'}
    require(out['reference_gradient']<1e-7,'fragment gradient')
    dump(f'fragment-{index}-{ghost}.json',out);emit('FRAGMENT',**out)
    return out

def summary(points):
    out={}
    for label in CONFIGS:
        rows={p['offset_degree']:p for p in points if p['label']==label}
        out[label]={}
        for meth in ('RHF','MP2'):
            vals={k:v[meth] for k,v in rows.items()};st={}
            for d in (.5,1.):
                h=math.radians(d)
                st[str(d)]={'slope':(vals[d]-vals[-d])/(2*h),
                            'curvature':(vals[d]+vals[-d]-2*vals[0])/h**2}
            st['richardson_slope']=(4*st['0.5']['slope']-st['1.0']['slope'])/3
            st['slope_step_discrepancy']=abs(st['0.5']['slope']-st['1.0']['slope'])
            out[label][meth]=st
    return out

def run():
    require(not (HERE/'freeze.json').exists(),'new scientific run must not overwrite prior record')
    files=[Path(__file__),REG,PROBE,OLD]
    for src in SOURCES.values():files.extend([src['path'],src['statepath']])
    freeze={str(p.relative_to(ROOT)):digest(p) for p in files}
    dump('freeze.json',{'time':datetime.datetime.now().astimezone().isoformat(),
                       'files':freeze,'configs':CONFIGS,'geometry':Q.tolist()})
    dump('status.json',{'state':'running','pid':os.getpid(),'wall_cap_seconds':1800})
    signal.signal(signal.SIGALRM,lambda *args: (_ for _ in ()).throw(TimeoutError('registered wall cap')))
    signal.alarm(1800)
    control={'atomic_imports':atomic_controls(),'pair_assembly':pair.controls()}
    # Before energies: positive support checked on all planned charts.
    control['planned_metrics']={label:metric(make(label,Q))[2] for label in CONFIGS}
    dump('controls.json',control);emit('CONTROLS_PASS')
    points=[]
    for label in CONFIGS:
        for off in (0.,-.5,.5,-1.,1.):
            points.append(one(label,off,gradients=(label=='T' and off==0)))
    slopes=summary(points);centers={p['label']:p for p in points if p['offset_degree']==0}
    for off in (0.,-.5,.5,-1.,1.):
        pp={p['label']:p for p in points if p['offset_degree']==off}
        require(pp['T']['RHF']<=pp['T-sp']['RHF']+2e-6,'angular variational gate')
        require(pp['T-tail']['RHF']<=pp['T']['RHF']+2e-6,'diffuse variational gate')
    analytical={m:centers['T']['analytic_angular_'+m]-slopes['T'][m]['richardson_slope'] for m in ('RHF','MP2')}
    require(max(abs(x) for x in analytical.values())<2e-5,'analytic gradient mismatch')
    controls2={'angular_complement':complement(),'analytic_minus_finite_difference':analytical}
    xyz=atoms(Q);theta=.47;rot=np.array([[math.cos(theta),0,math.sin(theta)],[0,1,0],[-math.sin(theta),0,math.cos(theta)]])
    moved=[(s,tuple(np.array(p)@rot+[.31,-.22,.18])) for s,p in xyz]
    rotated=one('T',0,override=[moved[i] for i in [2,0,1]],tag='T-rigid-permuted')
    shifted=one('T',0,shift=100.,tag='T-energy-shift')
    controls2['rigid_permutation_errors']={m:rotated[m]-centers['T'][m] for m in ('RHF','MP2')}
    controls2['energy_zero_errors']={m:shifted[m]-1000-centers['T'][m] for m in ('RHF','MP2')}
    require(max(abs(v) for k in ('rigid_permutation_errors','energy_zero_errors') for v in controls2[k].values())<1e-7,'covariance or energy-zero gate')
    dump('molecular-controls.json',controls2)
    frags=[fragment(i,g) for g in (False,True) for i in range(3)]
    bsse={m:sum(r[m] for r in frags if not r['ghosts'])-sum(r[m] for r in frags if r['ghosts']) for m in ('RHF_or_ROHF','MP2')}
    result={'status':'bounded_reference_preflight_complete','points':len(points),'slopes':slopes,
            'controls':controls2,'basis_superposition_own_minus_ghost':bsse,
            'limitations':['Not a molecular equilibrium calculation or native-closure validation.',
            'MP2 is not UCCSD(T); no higher-order error bound.',
            'O axial atomic cardinal change 1.018046%; atomic removal intervals remain finite-basis.',
            'Atom-fragment ghost orientation not certified; BSSE is diagnostic only.']}
    require(all(digest(ROOT/p)==h for p,h in freeze.items()),'frozen input changed')
    dump('result.json',result);dump('status.json',{'state':'completed','pid':os.getpid()})
    emit('COMPLETE',points=len(points),slopes=slopes,BSSE=bsse)

if __name__=='__main__':
    try:run()
    except Exception as exc:
        dump('status.json',{'state':'stopped_failure','pid':os.getpid(),'error':repr(exc)})
        emit('STOPPED_FAILURE',error=repr(exc));raise
