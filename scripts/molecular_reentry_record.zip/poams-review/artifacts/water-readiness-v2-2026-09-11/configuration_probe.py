"""All double replacements, pair-only second order. Not full configuration CI."""
import itertools
import numpy as np


def cofactor_second_order(g, occupied, virtual):
    """g[i,j,a,b]=(ia|jb); enumerate unique oriented sense-slot pairs.

    The two sense labels are the conventional spin translation in this evaluator.
    Their use does not establish an independent native exclusion theorem.
    """
    no,nv=len(occupied),len(virtual)
    aa,bb=np.triu_indices(2*nv,1);a,b=aa//2,bb//2;sa,sb=aa%2,bb%2
    ec=0.;norm2=0.;coupling2=0.;maxamp=0.;gapmin=float('inf');count=0
    for ii,jj in itertools.combinations(range(2*no),2):
        i,j=ii//2,jj//2;si,sj=ii%2,jj%2
        # Removal/reinsertion cofactors: direct minus crossed posting.
        v=g[i,j,a,b]*((sa==si)&(sb==sj))-g[j,i,a,b]*((sa==sj)&(sb==si))
        gap=virtual[a]+virtual[b]-occupied[i]-occupied[j]
        gapmin=min(gapmin,float(gap.min()))
        if gapmin<=1e-5: raise ArithmeticError('UNRESOLVED_CONFIGURATION_GAP')
        amp=v/gap;ec-=float(np.sum(v*amp));norm2+=float(amp@amp)
        coupling2+=float(v@v);maxamp=max(maxamp,float(np.max(abs(amp))))
        count+=len(v)
    return {'energy':ec,'double_replacement_count':count,
            'pair_coupling_norm':float(np.sqrt(coupling2)),
            'first_order_amplitude_norm':float(np.sqrt(norm2)),
            'max_individual_amplitude':maxamp,'smallest_gap':gapmin,
            'perturbative_readiness':bool(norm2<.5 and maxamp<.2),
            'scope':'second-order probe; no rigorous higher-order remainder bound'}


def spatial_second_order(g,occupied,virtual):
    gap=(virtual[None,None,:,None]+virtual[None,None,None,:]
         -occupied[:,None,None,None]-occupied[None,:,None,None])
    return -float(np.sum(g*(2*g-g.swapaxes(2,3))/gap))


def controls():
    rng=np.random.default_rng(20260911);no,nv=2,3
    # A symmetric real pair tensor restricted to occupied/unoccupied products.
    raw=rng.normal(size=(no*nv,no*nv))*.01
    raw=(raw+raw.T)/2;g=raw.reshape(no,nv,no,nv).transpose(0,2,1,3)
    occ=np.array([-1.,-.4]);vir=np.array([.2,.8,1.3])
    a=cofactor_second_order(g,occ,vir);b=spatial_second_order(g,occ,vir)
    assert abs(a['energy']-b)<1e-13
    zero=cofactor_second_order(np.zeros_like(g),occ,vir);assert zero['energy']==0
    # Exactly soluble two-configuration weak-coupling test.
    gap=2.;t=.01;exact=np.linalg.eigvalsh([[0.,t],[t,gap]])[0]
    second=-t*t/gap
    assert abs(exact-second)<1e-8 and exact<0 and second<0
    # Duplicate sense slots never occur in combinations; n choose 2, not n².
    assert len(list(itertools.combinations(range(4),2)))==6
    try: cofactor_second_order(g,occ,np.array([-2.,0.,1.]))
    except ArithmeticError: rejected=True
    else: rejected=False
    assert rejected
    return {'pass':True,'cofactor_vs_spatial_difference':a['energy']-b,
            'separated_entry_correction':zero['energy'],
            'weak_coupling_exact':float(exact),'weak_coupling_second_order':second,
            'invalid_gap_rejected':rejected}

if __name__=='__main__':
    import json
    print(json.dumps(controls(),indent=2))
