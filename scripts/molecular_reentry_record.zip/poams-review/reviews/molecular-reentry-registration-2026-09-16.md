# Molecular re-entry: bounded atomic-to-water bridge, 2026-09-16

## Authorization and scope

Star Lord asked to cache-bust Elements and resume Molecules after publication
of the correlated atomic benchmark. The blanket molecular hold is lifted for
bounded fixed-geometry diagnostics. No multi-day geometry optimization is
launched or certified here. Earlier water FAIL, methane PARTIAL, stopped
methanol, their thresholds and source files remain unchanged.

The September 11 angular-extension attempt stopped before molecular evaluation:
its multiplied oxygen radial conversion errors were 1.84% and 24.0%, against
its 0.02% gate. We do not restart it or quietly weaken that gate. This new
diagnostic uses the Gaussian representations actually exported by the atomic
campaign directly. It is a **conventional finite-basis reference bridge**, not
a repair or first-principles validation of the old native closure rule.

## Frozen inputs and stages

Use the saved water-v1 calculated minimum (two independently stored O-H
distances, angle about 108.011 degrees), NOT the observed equilibrium geometry.
The only molecular points are this angle and offsets -1, -0.5, +0.5, +1 degree.
Distances stay fixed. No optimizer, experimental-angle scoring or inferred
equilibrium angle is permitted in this diagnostic.

1. Read the exact H/O basis definitions and zero-field state arrays from the
   hashed correlated-atom records. Reproduce their single-centre overlaps and
   orbital normalization; embed their occupied reference directions in the
   molecular chart. Atomic densities/amplitudes are not themselves molecular
   joint states. Do not add atomic correlation energies or dispersion tails.
2. Compare four declared representations: full single-augmented D and T;
   T retaining complete s/p families only; full T with O's three diffuse
   layers and H's single layer. Every angular shell includes all 2l+1 members.
   The s/p diagnostic is a nested restriction of this new T representation,
   NOT the earlier 135-function water basis. Cardinal changes are not nested
   variational comparisons. T-a1 is nested in T-Oa3.
3. Use the entire resolved positive finite overlap support. No Krylov truncation
   or energy-dependent support cutoff. Require smallest normalized overlap root
   above 64*n*epsilon*norm(S), overlap metric defect <1e-8, every occupied
   atomic seed retained <1e-9, final RHF orbital gradient <1e-7. Stop on any
   mandatory failure; no basis/cutoff adjustment toward a desired answer.
4. At each of the 20 points solve closed-shell RHF and all-entry MP2 using
   direct four-centre integrals. Compare the MP2 library result to independent
   antisymmetrized double-replacement contraction (difference <1e-8 E*).
   Require positive pair gaps >1e-5 E*, amplitude norm squared <0.5 and
   maximum amplitude <0.2. These are perturbative diagnostics, not error bounds.
5. At the T center measure final s/p-action leakage into the full angular
   complement before relaxation. Verify nested RHF energy nonincrease <2e-6 E*.
   Separate angular, configuration and their interaction effects on the slope.
6. Compare central slopes/curvatures at 0.5/1-degree steps. A slope effect is
   resolved only if larger than ten times the stencil discrepancy and 1e-5
   E*/radian. At full T center, compare RHF/MP2 analytic angular derivatives
   with Richardson finite differences (<2e-5 E*/radian). Test rigid rotation,
   endpoint permutation and a +100 E* one-body energy zero shift (<1e-7 E*
   after subtracting the known 10-entry shift). None changes physical support.
7. At the same T center calculate atomic-fragment basis-superposition
   diagnostics at RHF/MP2 in own and ghost-augmented bases. Oxygen is triplet,
   hydrogen doublet, using ROHF-seeded semicanonical UMP2 as in atomic references.
   This is atomization-basis sensitivity, NOT an experimental binding energy
   or validated dissociation curve. Track occupied-state spin/overlap and
   flag a ghost solution with a different state instead of declaring a bond.

## Limits and resources

Measured alpha supplies units. All calculations are nonrelativistic, infinite-
inertia point-compact references, no internal compact geometry. MP2 is a
bounded second-order joint-configuration test, not the atomic UCCSD(T) accuracy
level. The O 1.018046% axial cardinal difference and separate C/N/O removal-
energy limitations remain in the handoff. No numerical or physical molecular
accuracy follows solely from passing isolated-atom checks.

One worker, one BLAS thread, 3 GB requested working allocation, 30-minute
wall cap; checkpoints after each point and no automatic restart. Stop at a
failed mandatory numerical gate, retain logs, and report it. Source hashes,
registration hash, atomic records and basis definitions are frozen before the
first molecular energy. A completed preflight only informs the next method
decision; it is not a water validation verdict or clearance for a long run.

Primary implementation references: [PySCF MP2](https://pyscf.org/user/mp.html)
and [molecular structure/basis API](https://pyscf.org/user/gto.html).
