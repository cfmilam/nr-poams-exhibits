# Full-space water reference after seed-retention failure

Registered 2026-09-16 after the first bounded re-entry stopped. This is a new
exposed-data diagnostic, not an amendment to its failed seed-retention gate.

The original run saved five D-basis points, then stopped at the first T-sp
point, before evaluating that point. Oxygen's exported occupied reference has
nonzero coefficients outside s/p (coefficient norms 0.0120231 and 0.00587588
in the two intrinsic sectors). Coefficient norms are chart-dependent, not
probabilities, but establish that these components are not exactly absent.
The planned restricted representation therefore fails the occupied-seed
containment requirement. No cutoff was relaxed; no truncated molecular result
was produced. Its source, registration, failure log, inputs and points remain.

## Permitted new diagnostic

Use only the three full representations already registered: D, T, and T with
oxygen's third diffuse layer. All imported directions and all angular shell
members remain present. Repeat the same five fixed angles per basis, retaining
every original convergence, direct-integral, joint-pair, metric, derivative,
energy-zero, chart/permutation, and ghost-fragment diagnostic and tolerance.
No T-sp energy is attempted. No angular-only effect or angular/configuration
factorization is claimed: the prescribed nested restriction did not qualify.

This full finite-space reference does not earn the original reduced-model gate,
native minimal closure or any speed advantage. Changes between D/T combine
radial and angular effects. Full T versus its diffuse extension tests additional
radial reach, with the same occupied space preserved. RHF/MP2 differences are
same-space correlation diagnostics, not UCCSD(T)-quality molecular results.

Fifteen main points plus the original two covariance checks and six fragment
checks; one worker, one BLAS thread, requested 3 GB allocation, 30-minute cap,
no automatic restart, no optimization, no fitting or experimental scoring.
All output goes to a separate full-space directory and is hashed before energy
evaluation. A failure still stops this new run rather than loosening thresholds.
