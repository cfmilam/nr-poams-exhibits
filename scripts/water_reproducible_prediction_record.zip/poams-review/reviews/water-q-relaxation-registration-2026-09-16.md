# Water Q-basis relaxation and T/Q comparison

Registered before the first new calculation. User authorized proceeding after
the completed T-basis reference, published as f21a6d1. This is a new bounded
experiment; all prior sources, records, thresholds and failures stay frozen.

## Question and declared model

Find the actual Q-basis local minimum near the calculated T minimum, and
measure the T-to-Q geometry shift rather than calling an unrelaxed Newton
estimate a second equilibrium. Use all-entry RCCSD(T), all 201 Q functions,
the same published H/O atomic exports, explicit four-centre integrals, measured
alpha units and the nonrelativistic infinite-inertia point-compact operator.
This remains an adopted effective-model reference, not a derivation of a native
POAMS interaction law. No observed geometry, target energy, empirical
correction, isolated-atom correlation offset or added dispersion tail enters.

Start from the exact saved T geometry, independently vary both bond distances
and the angle, and do not impose equality. First reproduce the previously saved
Q energy there within 1e-8 E*. Prior T result, its successful audit, all frozen
inputs and the new registration/producer/auditor/coordinator are hashed before
the first solve. Abort on a mismatch. Write only to the new Q directory.

## Numerical controls and resource bounds

Retain the previous solver, metric, support, amplitude and reference-screening
thresholds. L-BFGS-B coordinate scales are (0.05 A, 0.05 A, 0.2 rad), with a
search box +/-0.15 A and +/-0.35 rad around the calculated T start. Reject a
boundary solution. Full central gradients use (0.0002 A, 0.0002 A, 0.0004 rad).
Max 20 iterations, 200 objective points plus one independently solved final
centre, one worker/BLAS thread, two-hour calculation cap. A supervising process
also enforces a wall cap. No automatic retry, widening or threshold relaxation.

Require final full/half-step Richardson gradients below 2e-5 E*/A, E*/A,
E*/rad, and full/half disagreement below 5e-6. Rebuild the final Q state with
independent analytic RHF/CCSD gradients and RHF internal/external stability.
The analytic gradients check their named methods, NOT CCSD(T). Compare the
RHF/CCSD analytic and energy-difference gradients within 2e-5 in each internal
coordinate. Check normalization, occupied support and entry count again.

Use the full Q internal Hessian at steps (0.002 A,0.002 A,0.004 rad), including
cross terms; half-step diagonal changes below 0.002 in the stated units;
coordinate-scaled eigenvalues above 1e-4 E*. These are local curvatures, not
frequencies. Independently swap the two bond coordinates and require energy
agreement within 1e-8 E*. Preserve independent coordinates even if equal.

## Basis comparison and limits

Report the actual Q-minus-T distances and angle, and compare them with the
previously saved local shift estimate. Estimate agreement is diagnostic, not
an acceptance gate. Separately report the Q energy decrease from its own value
at the T geometry; do not conflate that with the T-to-Q basis energy difference.

At the Q minimum evaluate T and T plus the existing oxygen diffuse extension,
including three gradients. Their difference is a lower-cardinal diffuse
sensitivity diagnostic only, not a Q diffuse-convergence certificate. Use the
Q Hessian for explicitly labeled local displacement estimates only.

No numerical geometry-accuracy threshold is chosen from the new result.
One T/Q pair of relaxed minima does NOT establish the complete-basis limit or
an experimental uncertainty interval. No claim of full higher excitations,
recoil/relativity, vibrational averaging, dissociation, atomization energy,
global minimum or helium-level precision. Preserve the O 1.018046% atomic
response limit and removal limits without inventing a molecular percentage.

An independent consumer reconstructs stencils, full/half curvature, symmetry,
analytic comparisons, geometry and energy differences, and all source hashes.
The coordinator audits only on successful completion, then stops for review;
it neither publishes nor starts another scientific experiment.
