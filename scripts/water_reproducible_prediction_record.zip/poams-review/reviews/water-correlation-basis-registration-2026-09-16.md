# Water: higher-order correlation and basis gate

Registered after the published fixed-geometry RHF/MP2 re-entry, before new
coupled-cluster molecular energies are calculated. User authorized proceeding.
This is a new finite-space reference experiment, not a repair of the stopped
native solver or its failed s/p-only occupied-seed reduction.

## Inputs and scope

Use the unaltered earlier calculated geometry and published H/O atomic basis
and occupied-state exports. Full angular/radial support is retained. Add the
published single-augmented Q basis to the D, T and O triple-diffuse T controls.
Same nonrelativistic, infinite-inertia point-compact operator and measured
alpha units; all ten occupied entries correlated, direct four-centre integrals,
no density fitting, frozen core, empirical geometry input or fitted correction.
No isolated atomic correlation energy or dispersion tail is added to a
molecular energy. Closed-shell RCCSD and perturbative triples RCCSD(T) are
explicit effective-model references, not a new derivation from POAMS ontology.

## Fixed-geometry comparisons

- Five angles (old angle + 0, +/-0.5, +/-1 degree) at D/T/Q/T-tail.
- At T and Q, five symmetric-distance points (both old distances + 0,
  +/-0.002, +/-0.004 angstrom), keeping the old angle. Centres are shared.
- Store RHF, MP2, CCSD and CCSD(T) at every point. Two-step Richardson
  estimates separate finite-difference error from basis and correlation shifts.
- Independent analytic RHF/CCSD Cartesian gradients at T/Q centres, transformed
  to all three internal coordinates, check the angular and symmetric stretch
  finite differences. Do not infer an equilibrium from a one-dimensional slope.
- D-centre UCCSD(T) check of the closed-shell RCCSD(T) implementation; T-centre
  rigid rotation/translation plus endpoint permutation and D-centre known
  energy-zero shift check. Preserve all first-attempt failures if any.

## Numerical gates

Retain prior positive full-overlap support/seed-containment gates. SCF energy
tolerance 1e-12, orbital-gradient norm <1e-7, final metric defect <1e-8.
CCSD energy tolerance 1e-11 and amplitude tolerance 1e-9; require explicit
convergence and one additional amplitude-update norm <2e-8. Positive reference
gap, T1 diagnostic <0.02 and D1 <0.05 are screening flags, not correlation error
bounds. Check pair contractions against the existing independent MP2 routine.
Analytic versus Richardson derivatives must differ by <2e-5 E*/radian (angle)
or E*/angstrom (symmetric stretch); covariance/energy-zero corrected differences
<1e-7 E*. RHF internal and external stability at the T centre must pass.

A bounded new equilibrium experiment may be registered only if numerical gates
pass, T/Q and T/T-tail angular descent signs agree with resolved signal (>10
times stencil discrepancy and the 2e-5 floor), and the CCSD(T) versus CCSD
gradient correction and T/Q shift each stay below 25% of the nonzero CCSD(T)
gradient component. For a component near zero, require changes <2e-4 in its
stated units instead. These are conservative *local-descent* staging criteria,
not 25% accuracy claims, equilibrium error bounds or experimental validation.
If they fail, report the diagnostic and identify the necessary refinement.
Even if they pass, freeze a separate bounded three-coordinate experiment before
optimization and verify its stationary point, local curvature and basis limits.

## Execution and reporting

One worker, one BLAS thread, requested 3 GB per library calculation, a two-hour
wall cap, atomic per-point checkpoints and source/input SHA-256 freeze. No
automatic relaunch or modification of historical sources. Use no target-angle
or target-energy scoring to choose parameters. Carry O's 1.018046% atomic
axial cardinal limit, atomic removal limitations and previous molecular
FAIL/PARTIAL records forward. No spectral, dissociation, nuclear-motion or
helium-level precision claim. Report numerical completion separately from
model adequacy, and preserve the actual method names in the reproducibility
record even where the exhibit uses rate-first POAMS terminology.
