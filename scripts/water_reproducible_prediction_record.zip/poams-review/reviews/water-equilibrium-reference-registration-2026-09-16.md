# Conditional bounded water equilibrium reference

Registered before optimization or new equilibrium comparisons. User authorized
continuing higher-order/basis checks, then optimization if justified. This
conditional experiment is separate from all old native molecular records.

## Entry condition

Do not launch until the water-correlation-basis campaign finishes, its
independent consumer audit passes, and every registered local-descent staging
gate passes. The runner freezes the completed comparison, its audit, this
registration, all model inputs and both scientific sources before its first
objective call. If any gate fails, no optimization is performed or substituted.
No operator, support, convergence or staging threshold is relaxed to qualify.

## Calculation

Optimize all three independent internal coordinates: both O-H distances and
the included angle, starting from the earlier *calculated* geometry. Do not
impose equal bonds or insert an observed water geometry. Objective: all-entry,
direct-integral closed-shell RCCSD(T), full published single-augmented T atomic
basis, same nonrelativistic infinite-inertia point-compact operator. No ghost
correction, isolated atomic correlation energy or fitted term is added.

Use L-BFGS-B with coordinate scales (0.05 angstrom, 0.05 angstrom, 0.2 radian).
Bounds are start +/-0.15 angstrom for each distance and +/-0.35 radian for angle;
reject a boundary solution. Central energy differences at (0.0002 angstrom,
0.0002 angstrom, 0.0004 radian) supply all three gradient entries. Max20 optimizer
iterations, max200 distinct energy points, one worker/thread, two-hour cap;
there is no unattended multi-day optimizer or automatic replacement attempt.

Require solver convergence and independent half-step/Richardson gradients below
2e-5 E*/angstrom for each distance and 2e-5 E*/radian for angle; full/half-step
gradient disagreement <5e-6. Verify RHF internal/external stability and the
full exported metric and occupied-support gates at the final point.

Compute a full three-by-three internal Hessian from energy differences at
(0.002 angstrom, 0.002 angstrom, 0.004 radian), including cross terms; repeat
the diagonal at half step (change <0.002 in stated Hessian units). All eigenvalues
of the coordinate-scaled Hessian must exceed1e-4 E*. This checks a resolved
local minimum, not a global minimum or vibrational frequencies. Swap endpoints
independently; energy must agree within1e-8 E* without imposing their equality.

At the T stationary geometry, calculate the Q and triple-diffuse T energies
and all three central-difference gradient entries. Report these **unrelaxed**
basis checks explicitly. A displacement obtained by applying the T Hessian to
those gradients is only a local Newton estimate, not a Q/diffuse equilibrium.
Nonzero basis gradients must remain visible, not be called basis convergence.

## Acceptance and reporting

An independent read-only audit recomputes all stencils, curvature, state counts,
normalization and input hashes. A passed result is a *finite-T-space effective
model local minimum*, not native-closure validation, a new alpha derivation,
an experimental accuracy qualification or a helium-precision water solution.
No experimental value is used to select parameters or to stop the optimization.
Recoil, relativity, full higher excitations, nuclear motion, dissociation,
global exploration and basis-limit geometry remain outside this experiment.
O's published1.018046% atomic axial cardinal sensitivity and separate removal
limits are retained as atomic facts, not pasted onto the molecular result as
an invented percentage error. Keep previous water FAIL, methane PARTIAL,
stopped methanol, failed radial conversion and failed s/p restriction intact.
