#!/usr/bin/env python3
"""One-shot process supervisor and audit; no retries or additional experiments."""
from pathlib import Path
import datetime,json,os,signal,subprocess
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
PY=ROOT/'poams-review/.venvs/atomic-campaign/bin/python'
def write(name,data):
    p=HERE/name;t=p.with_suffix('.tmp');t.write_text(json.dumps(data,indent=2)+'\n');t.replace(p)
def status(state,**extra):
    data={'state':state,'pid':os.getpid(),'updated':datetime.datetime.now().astimezone().isoformat(),**extra}
    write('followthrough-status.json',data);print(json.dumps(data),flush=True)
def execute(script,timeout):
    with (HERE/(script.stem+'.log')).open('ab',buffering=0) as out:
        p=subprocess.Popen([str(PY),str(script)],cwd=ROOT,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
        status('running_'+script.stem,child_pid=p.pid)
        try:return p.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            os.killpg(p.pid,signal.SIGTERM)
            try:p.wait(timeout=15)
            except subprocess.TimeoutExpired:
                os.killpg(p.pid,signal.SIGKILL);p.wait()
            write('status.json',{'state':'stopped_wall_cap','pid':p.pid,'wall_cap_seconds':timeout})
            status('stopped_wall_cap',child_pid=p.pid);return 124
def main():
    if (HERE/'result.json').exists():raise RuntimeError('result already exists; refusing duplicate campaign')
    code=execute(HERE/'optimize.py',7250)
    if code:status('stopped_optimization',exit_code=code);return
    code=execute(HERE/'audit.py',300)
    status('ready_for_publication_review' if code==0 else 'stopped_audit',exit_code=code)
if __name__=='__main__':
    try:main()
    except Exception as exc:status('stopped_supervisor',error=repr(exc));raise
