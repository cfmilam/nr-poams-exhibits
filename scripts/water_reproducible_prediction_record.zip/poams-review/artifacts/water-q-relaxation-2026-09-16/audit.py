#!/usr/bin/env python3
"""Independent saved-record Q audit. Does not import or run the producer."""
from pathlib import Path
from decimal import Decimal, localcontext
import hashlib,json,math
import numpy as np
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
OLD=ROOT/'poams-review/artifacts/water-equilibrium-reference-2026-09-16'
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
checks=[]
def check(name,ok,value=None):checks.append({'check':name,'pass':bool(ok),'value':value})
def main():
    r=read(HERE/'result.json');f=read(HERE/'freeze.json');prior=read(OLD/'result.json')
    for p,h in f['files'].items():check('frozen '+p,sha(ROOT/p)==h)
    rows=[read(p) for p in HERE.glob('p-*.json')]
    def find(label,q):
        candidates=[a for a in rows if a['basis']==label and np.array_equal(np.array(a['geometry']),q)]
        if not candidates:
            candidates=[a for a in rows if a['basis']==label and np.max(abs(np.array(a['geometry'])-q))<1e-13]
        if len(candidates)!=1:raise AssertionError('missing/ambiguous '+label+' point '+str(q))
        return candidates[0]
    def e(label,q,method='CCSD(T)'):return Decimal(str(find(label,q)[method]))
    def gradient(label,q,h,method='CCSD(T)'):
        out=[]
        with localcontext() as ctx:
            ctx.prec=45
            for i,s in enumerate(h):
                v=np.zeros(3);v[i]=s
                out.append(float((e(label,q+v,method)-e(label,q-v,method))/(2*Decimal(str(s)))))
        return np.array(out)
    q=np.array(r['geometry']);start=np.array(f['start']);h=np.array(f['gradient_steps']);scale=np.array(f['scales'])
    check('complete',read(HERE/'status.json')['state']=='completed')
    check('basis Q',r['basis']=='Q')
    check('start from calculated T',np.array_equal(start,prior['geometry']) and np.array_equal(start,r['start_geometry']))
    for a in rows:
        check('complete '+a['basis'],a['complete'])
        check('CC residual',a['cc_diagnostics']['amplitude_update_norm']<2e-8)
        check('reference screened',a['cc_diagnostics']['gap']>0 and a['cc_diagnostics']['t1']<.02 and a['cc_diagnostics']['d1']<.05)
        check('metric',a['metric']['final_orbital_metric_defect']<1e-8)
        check('support',a['metric']['seed_containment_defect']<1e-9 and a['metric']['rank']==a['nao'])
        check('pair contraction',abs(a['pair_check']['library_difference'])<1e-8)
        check('source custody',a['source_sha256']==sha(ROOT/'poams-review/artifacts/water-correlation-basis-2026-09-16/campaign.py'))
    g1=gradient('Q',q,h);g2=gradient('Q',q,h/2);g=(4*g2-g1)/3
    check('independent gradient',max(abs(g-r['gradient']))<1e-9,g.tolist())
    check('stationarity',max(abs(g))<2e-5)
    check('step disagreement',max(abs(g1-g2))<5e-6)
    check('reported step difference',max(abs(g1-g2-r['gradient_step_difference']))<1e-9)
    e0=e('Q',q);es=e('Q',start)
    check('Q start reproduction',abs(float(es)-prior['basis_checks']['Q']['energy'])<1e-8)
    check('lower Q energy',e0<es)
    check('same-basis energy decrease',abs(float(e0-es)-r['energy_change_from_start_same_basis'])<1e-10)
    check('energy',abs(float(e0)-r['energy'])<1e-10)
    hh=np.array(r['curvature']['steps']);mat=np.zeros((3,3));halves=[]
    for i,s in enumerate(hh):
        v=np.zeros(3);v[i]=s
        mat[i,i]=float(e('Q',q+v)+e('Q',q-v)-2*e0)/s**2
        halves.append(float(e('Q',q+v/2)+e('Q',q-v/2)-2*e0)/(s/2)**2)
        for j in range(i):
            w=np.zeros(3);w[j]=hh[j]
            mat[i,j]=mat[j,i]=float(e('Q',q+v+w)-e('Q',q+v-w)-e('Q',q-v+w)+e('Q',q-v-w))/(4*s*hh[j])
    eig=np.linalg.eigvalsh(mat*scale[:,None]*scale[None,:])
    check('independent full Hessian',max(abs(mat-np.array(r['curvature']['matrix_internal'])).flat)<1e-7)
    check('half diagonal agreement',max(abs(np.diag(mat)-halves))<.002)
    check('reported half diagonal',max(abs(np.array(halves)-r['curvature']['half_step_diagonal']))<1e-7)
    check('positive local curvature',min(eig)>1e-4,eig.tolist())
    check('reported eigenvalues',max(abs(eig-r['curvature']['scaled_eigenvalues']))<1e-8)
    symmetry=float(e('Q',q[[1,0,2]])-e0)
    check('endpoint symmetry',abs(symmetry)<1e-8)
    check('reported symmetry',abs(symmetry-r['endpoint_energy_difference'])<1e-10)
    delta=q-start;comp=r['relaxed_Q_minus_T']
    check('actual relaxed displacement',max(abs(delta-comp['internal']))<1e-12)
    check('distance pm conversion',max(abs(delta[:2]*100-comp['distances_pm']))<1e-10)
    check('angle degrees conversion',abs(math.degrees(delta[2])-comp['angle_degrees'])<1e-10)
    check('reported absolute angle',abs(math.degrees(q[2])-r['angle_degrees'])<1e-10)
    check('comparison to prior estimate',max(abs(delta-np.array(prior['basis_checks']['Q']['local_displacement_estimate'])-comp['actual_minus_estimate_internal']))<1e-12)
    x=delta/scale
    check('interior solution',all(lo+.01<t<hi-.01 for t,(lo,hi) in zip(x,f['bounds_scaled'])))
    check('bounded iterations',r['optimization']['success'] and r['optimization']['iterations']<=20)
    check('bounded points',len(rows)==r['unique_points'] and len(rows)<=200)
    gradients={}
    for label,b in r['basis_checks'].items():
        gb=gradient(label,q,h);gradients[label]=gb
        check(label+' gradient',max(abs(gb-b['gradient_at_Q_minimum']))<1e-9)
        check(label+' displacement estimate',max(abs(np.linalg.solve(mat,-gb)-b['local_displacement_estimate']))<1e-7)
    dg=gradients['T-tail']-gradients['T'];dd=r['diffuse_difference_at_lower_cardinal']
    check('diffuse gradient difference',max(abs(dg-dd['gradient_difference']))<1e-9)
    check('diffuse displacement diagnostic',max(abs(np.linalg.solve(mat,-dg)-dd['local_displacement_estimate']))<1e-7)
    final=read(HERE/'final-center.json')
    check('final state custody',sha(HERE/final['state_file'])==final['state_sha256'])
    check('reference stability',all(final['rhf_stability'].values()))
    check('final energy independently solved',abs(final['CCSD(T)']-float(e0))<1e-8)
    z=np.load(HERE/final['state_file'],allow_pickle=False)
    metric=z['mo_coeff'].T@z['overlap']@z['mo_coeff']
    check('final 201-function metric',metric.shape==(201,201) and np.linalg.norm(metric-np.eye(len(metric)),2)<1e-8)
    check('final ten-entry count',abs(np.einsum('ij,ji',z['density'],z['overlap'])-10)<1e-8)
    for method in ('RHF','CCSD'):
        fd=(4*gradient('Q',q,h/2,method)-gradient('Q',q,h,method))/3
        diff=np.array(final['analytic_gradients'][method]['internal'])-fd
        check(method+' analytic gradient',max(abs(diff))<2e-5,diff.tolist())
        check(method+' reported analytic check',max(abs(diff-r['analytic_minus_stencil'][method]))<1e-9)
    out={'passed':all(x['pass'] for x in checks),'count':len(checks),'checks':checks,
         'failures':[x for x in checks if not x['pass']]}
    (HERE/'audit.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:out[k] for k in ('passed','count','failures')}))
    if not out['passed']:raise SystemExit(1)
if __name__=='__main__':main()
