#!/usr/bin/env python3
"""Separate bounded Q relaxation; original T sources and records are read-only."""
import os
for name in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS'):
    os.environ[name] = '1'
from pathlib import Path
import datetime, hashlib, importlib.util, json, math, signal, sys
import numpy as np
from scipy.optimize import minimize

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
PRE = ROOT/'poams-review/artifacts/water-correlation-basis-2026-09-16'
OLD = ROOT/'poams-review/artifacts/water-equilibrium-reference-2026-09-16'
REG = ROOT/'poams-review/reviews/water-q-relaxation-registration-2026-09-16.md'
spec = importlib.util.spec_from_file_location('comparison', PRE/'campaign.py')
c = importlib.util.module_from_spec(spec); spec.loader.exec_module(c)
c.HERE = HERE; c.m.HERE = HERE
prior = json.loads((OLD/'result.json').read_text())
Q0 = np.array(prior['geometry'])
SCALE = np.array([.05,.05,.2]); H = np.array([.0002,.0002,.0004])
cache = {}; trajectory = []

def freeze():
    old_freeze = json.loads((OLD/'freeze.json').read_text())
    frozen = old_freeze['files'].copy()
    c.require(all(c.digest(ROOT/p) == h for p,h in frozen.items()), 'prior frozen input changed')
    c.require(json.loads((OLD/'audit.json').read_text())['passed'], 'prior T audit not passed')
    c.require(prior['status'] == 'bounded_T_equilibrium_reference_complete', 'prior T result incomplete')
    files = [Path(__file__), HERE/'audit.py', HERE/'followthrough.py', REG,
             OLD/'result.json', OLD/'audit.json', OLD/'freeze.json', OLD/'audit.py']
    for p in files: frozen[str(p.relative_to(ROOT))] = c.digest(p)
    record = {'files':frozen, 'start':Q0.tolist(), 'basis':'Q', 'scales':SCALE.tolist(),
              'gradient_steps':H.tolist(), 'bounds_scaled':[[-3.,3.],[-3.,3.],[-1.75,1.75]],
              'wall_cap_seconds':7200, 'max_points':200, 'max_iterations':20}
    if (HERE/'freeze.json').exists():
        c.require(json.loads((HERE/'freeze.json').read_text()) == record, 'new source/input freeze mismatch')
    else: c.dump('freeze.json', record)
    return frozen

def point(q, label='Q'):
    q = np.asarray(q); key = (label, tuple(q))
    if key not in cache:
        c.require(len(cache) < 200, 'registered 200-point cap reached')
        ident = hashlib.sha256((label+json.dumps(q.tolist())).encode()).hexdigest()[:18]
        cache[key] = c.solve(label, q, 'p-'+label+'-'+ident)
    return cache[key]

def energy(q, label='Q'): return point(q,label)['CCSD(T)']

def gradient(q, label='Q', steps=H, method='CCSD(T)'):
    out = []
    for i,h in enumerate(steps):
        v = np.zeros(3); v[i] = h
        out.append((point(q+v,label)[method]-point(q-v,label)[method])/(2*h))
    return np.array(out)

def objective(x):
    q = Q0+SCALE*x; e = energy(q); g = gradient(q)
    row = {'geometry':q.tolist(), 'energy':e, 'gradient':g.tolist(),
           'max_abs_gradient':float(max(abs(g)))}
    trajectory.append(row); c.dump('trajectory.json',trajectory); c.emit('OBJECTIVE',**row)
    return e,g*SCALE

def hessian(q):
    h = np.array([.002,.002,.004]); e = energy(q)
    mat = np.zeros((3,3)); half = []
    for i in range(3):
        v = np.zeros(3); v[i] = h[i]
        mat[i,i] = (energy(q+v)+energy(q-v)-2*e)/h[i]**2
        half.append((energy(q+v/2)+energy(q-v/2)-2*e)/(h[i]/2)**2)
        for j in range(i):
            w = np.zeros(3); w[j] = h[j]
            mat[i,j] = mat[j,i] = (energy(q+v+w)-energy(q+v-w)-energy(q-v+w)+energy(q-v-w))/(4*h[i]*h[j])
    vals = np.linalg.eigvalsh(SCALE[:,None]*mat*SCALE[None,:])
    c.require(min(vals)>1e-4, 'nonpositive or unresolved Q curvature')
    c.require(max(abs(np.diag(mat)-half))<.002, 'Q Hessian step check')
    return {'matrix_internal':mat.tolist(),'scaled_eigenvalues':vals.tolist(),
            'coordinate_scales':SCALE.tolist(),'steps':h.tolist(),'half_step_diagonal':half,
            'scope':'positive local internal curvature, not frequencies or global minimality'}

def run():
    frozen = freeze()
    c.require(not (HERE/'result.json').exists(), 'completed result exists; no automatic rerun')
    c.dump('status.json', {'state':'running','pid':os.getpid(),'basis':'Q','wall_cap_seconds':7200})
    def cap(*args): raise TimeoutError('registered two-hour calculation cap')
    signal.signal(signal.SIGALRM,cap); signal.alarm(7200)
    start_energy = energy(Q0)
    start_difference = start_energy-prior['basis_checks']['Q']['energy']
    c.require(abs(start_difference)<1e-8, 'previous Q-at-T energy not reproduced')
    c.dump('start-control.json', {'difference':start_difference,'energy':start_energy,
                                'geometry':Q0.tolist(),'passed':True})
    bounds = [(-3.,3.),(-3.,3.),(-1.75,1.75)]
    res = minimize(objective,np.zeros(3),jac=True,method='L-BFGS-B',bounds=bounds,
                   options={'maxiter':20,'maxls':8,'ftol':1e-13,'gtol':1e-7})
    q = Q0+SCALE*res.x
    c.require(res.success, 'optimizer not converged: '+str(res.message))
    c.require(all(lo+.01<x<hi-.01 for x,(lo,hi) in zip(res.x,bounds)), 'boundary minimum')
    g1 = gradient(q); g2 = gradient(q,steps=H/2); gr = (4*g2-g1)/3
    c.require(max(abs(gr))<2e-5, 'final Q stationarity')
    c.require(max(abs(g1-g2))<5e-6, 'final Q derivative step check')
    centre = c.solve('Q',q,'final-center',analytic=True,stability=True)
    analytic = {}
    for method in ('RHF','CCSD'):
        gf = gradient(q,method=method); gh = gradient(q,steps=H/2,method=method)
        difference = np.array(centre['analytic_gradients'][method]['internal'])-(4*gh-gf)/3
        c.require(max(abs(difference))<2e-5, 'final analytic '+method+' gradient check')
        analytic[method] = difference.tolist()
    hs = hessian(q)
    symmetry = energy(q[[1,0,2]])-energy(q)
    c.require(abs(symmetry)<1e-8, 'Q endpoint permutation')
    basis = {}
    for label in ('T','T-tail'):
        e = energy(q,label); g = gradient(q,label)
        basis[label] = {'energy':e,'gradient_at_Q_minimum':g.tolist(),
                        'local_displacement_estimate':np.linalg.solve(np.array(hs['matrix_internal']),-g).tolist(),
                        'scope':'unrelaxed lower-cardinal comparison, not a Q diffuse limit'}
    dg = np.array(basis['T-tail']['gradient_at_Q_minimum'])-basis['T']['gradient_at_Q_minimum']
    delta = q-Q0; old_estimate = np.array(prior['basis_checks']['Q']['local_displacement_estimate'])
    c.require(all(c.digest(ROOT/p)==h for p,h in frozen.items()),'source/input mutation')
    result = {'status':'bounded_Q_equilibrium_reference_complete','basis':'Q',
       'method':'all-entry RCCSD(T)','geometry':q.tolist(),'start_geometry':Q0.tolist(),
       'distances_angstrom':q[:2].tolist(),'angle_degrees':float(math.degrees(q[2])),
       'energy':energy(q),'energy_at_T_geometry_in_Q':start_energy,
       'energy_change_from_start_same_basis':energy(q)-start_energy,
       'start_reproduction_difference':start_difference,'gradient':gr.tolist(),
       'gradient_step_difference':(g1-g2).tolist(),'analytic_minus_stencil':analytic,
       'curvature':hs,'endpoint_energy_difference':symmetry,'basis_checks':basis,
       'diffuse_difference_at_lower_cardinal':{'gradient_difference':dg.tolist(),
         'local_displacement_estimate':np.linalg.solve(np.array(hs['matrix_internal']),-dg).tolist(),
         'scope':'T-tail minus T at Q geometry, not Q diffuse convergence'},
       'relaxed_Q_minus_T':{'internal':delta.tolist(),'distances_pm':(delta[:2]*100).tolist(),
         'angle_degrees':float(math.degrees(delta[2])),
         'previous_unrelaxed_estimate_internal':old_estimate.tolist(),
         'actual_minus_estimate_internal':(delta-old_estimate).tolist(),
         'scope':'difference between two finite-basis minima, not a basis-limit error bar'},
       'optimization':{'success':bool(res.success),'message':str(res.message),'iterations':res.nit,'evaluations':res.nfev},
       'unique_points':len(cache),'limitations':[
         'Adopted effective-model local minimum, not native POAMS closure or global minimization.',
         'Two relaxed basis points do not establish the complete-basis limit or experimental precision.',
         'Lower-cardinal diffuse gradient does not certify Q diffuse convergence.',
         'No full higher excitations, recoil, relativity, nuclear-motion or dissociation prediction.',
         'Original native failures and atomic O response/removal limits retained.']}
    c.dump('result.json',result); c.dump('status.json',{'state':'completed','pid':os.getpid(),'basis':'Q'})
    c.emit('COMPLETE',geometry=q.tolist(),angle_degrees=result['angle_degrees'])

if __name__=='__main__':
    try:
        if '--preflight' in sys.argv:
            files = freeze()
            c.require(c.m.make('Q',Q0).nao==201,'unexpected Q dimension')
            print(json.dumps({'preflight':'passed','frozen_files':len(files),'Q_functions':201,'start':Q0.tolist()}))
        else: run()
    except Exception as exc:
        c.dump('status.json',{'state':'stopped_failure','pid':os.getpid(),'error':repr(exc)})
        c.emit('STOPPED_FAILURE',error=repr(exc)); raise
