#!/usr/bin/env python3
"""Water reproducible-prediction driver — 17 Sep 2026.

Consumes the frozen Q equilibrium reference; computes:
  1. harmonic vibrational frequencies from Wilson GF at the Q minimum;
  2. static-nuclei electronic atomization energy at cc-pVQZ.

Uses only the same PySCF stack that produced the Q reference.
Emits per-point records for the atomic energies and a final result.json.
"""
from __future__ import annotations

import argparse
import datetime
import hashlib
import json
import math
import os
import sys
from pathlib import Path

import numpy as np

WORKSPACE = Path("/Users/cfmacbook/.openclaw/workspace")
ART = WORKSPACE / "poams-review/artifacts/water-reproducible-prediction-2026-09-17"
Q_REF = WORKSPACE / "poams-review/artifacts/water-q-relaxation-2026-09-16/result.json"
Q_FREEZE = WORKSPACE / "poams-review/artifacts/water-q-relaxation-2026-09-16/freeze.json"

# --- physical constants (CODATA 2018 / 2019 SI redefinition) ---
HARTREE_J = 4.359_744_722_2071e-18  # J
BOHR_M = 5.291_772_1090_3e-11        # m
ANGSTROM_M = 1e-10                   # m
U_KG = 1.660_539_066_60e-27          # kg per unified atomic mass unit
C_M_S = 299_792_458.0                # m/s
NA = 6.022_140_76e23                 # Avogadro
E_CHARGE = 1.602_176_634e-19         # C (for eV)
KCAL_MOL_PER_HA = HARTREE_J * NA / 4184.0  # 627.5094740631...
EV_PER_HA = HARTREE_J / E_CHARGE           # 27.211386245988...

# --- masses (bound-state isotopes) ---
M_H1 = 1.00782503207 * U_KG   # ¹H
M_O16 = 15.99491461957 * U_KG  # ¹⁶O


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def verify_frozen_inputs() -> dict:
    """Return {relpath: sha256} and raise if anything changed since Q freeze."""
    freeze = json.loads(Q_FREEZE.read_text())
    diffs = []
    checked = {}
    for rel, expected in freeze["files"].items():
        p = WORKSPACE / rel
        actual = sha256_file(p)
        checked[rel] = actual
        if actual != expected:
            diffs.append((rel, expected, actual))
    if diffs:
        raise RuntimeError(f"frozen upstream drift: {diffs[:3]} …")
    return checked


# --- Wilson GF for symmetric AB2 in (r1, r2, theta) ---

def wilson_G(r1: float, r2: float, theta: float,
             m_a: float, m_b: float) -> np.ndarray:
    """G matrix for B–A–B with internal coords (r1, r2, theta).
    r1, r2 in metres; theta in radians; masses in kg.
    Elements from Wilson, Decius, Cross (1955), Table 4-4.
    Returns G in units of 1/kg (r,r), 1/(kg·m) (r,theta), 1/(kg·m²) (theta,theta).
    """
    ct, st = math.cos(theta), math.sin(theta)
    G = np.zeros((3, 3))
    G[0, 0] = 1.0/m_b + 1.0/m_a
    G[1, 1] = 1.0/m_b + 1.0/m_a
    G[0, 1] = G[1, 0] = ct / m_a
    G[0, 2] = G[2, 0] = -st / (m_a * r2)
    G[1, 2] = G[2, 1] = -st / (m_a * r1)
    G[2, 2] = (1.0/(m_b * r1*r1) + 1.0/(m_b * r2*r2)
               + (1.0/m_a) * (1.0/(r1*r1) + 1.0/(r2*r2) - 2.0*ct/(r1*r2)))
    return G


def hessian_SI(F_internal: np.ndarray) -> np.ndarray:
    """Convert Hessian from Hartree/Å² and Hartree/rad² to SI (J/m² and J/rad²).
    r indices 0,1 use Å→m; index 2 uses rad."""
    F = np.array(F_internal, dtype=float)
    S = np.array([1.0/ANGSTROM_M, 1.0/ANGSTROM_M, 1.0])
    # element (i,j): F_ij * HARTREE_J * S[i] * S[j]
    return HARTREE_J * (F * np.outer(S, S))


def frequencies_cm1(F_int: np.ndarray, geometry_A: tuple[float, float, float],
                    m_a: float, m_b: float) -> dict:
    r1_m = geometry_A[0] * ANGSTROM_M
    r2_m = geometry_A[1] * ANGSTROM_M
    theta = geometry_A[2]  # radians
    G = wilson_G(r1_m, r2_m, theta, m_a, m_b)
    F = hessian_SI(F_int)
    GF = G @ F
    lam, vec = np.linalg.eig(GF)
    # lam has units rad²/s² (positive for real modes); take sqrt
    order = np.argsort(np.real(lam))
    lam = np.real(lam[order])
    vec = np.real(vec[:, order])
    omega_rad_s = np.sqrt(np.maximum(lam, 0.0))
    nu_cm1 = omega_rad_s / (2.0 * math.pi * C_M_S * 100.0)
    return {
        "G_1_kg_or_1_kg_m2": G.tolist(),
        "F_SI_J_per_m2_or_rad2": F.tolist(),
        "GF": GF.tolist(),
        "eigenvalues_rad2_s2": lam.tolist(),
        "eigenvectors_columns_in_internal_coords": vec.tolist(),
        "omega_rad_s": omega_rad_s.tolist(),
        "omega_cm1": nu_cm1.tolist(),
    }


# --- atomic energies via PySCF ---

def compute_H_atom(basis: str = "cc-pvqz") -> dict:
    from pyscf import gto, scf
    mol = gto.Mole()
    mol.atom = "H 0 0 0"
    mol.basis = basis
    mol.spin = 1
    mol.charge = 0
    mol.symmetry = False
    mol.verbose = 0
    mol.max_memory = 3000
    mol.build()
    mf = scf.ROHF(mol)
    e_scf = mf.kernel()
    if not mf.converged:
        raise RuntimeError("H ROHF did not converge")
    # For a one-electron atom, ROHF = ROHF-CCSD(T) exactly; report both trivially.
    return {
        "atom": "H",
        "isotope": "1H",
        "basis": basis,
        "method": "ROHF (exact for 1e; RCCSD(T) equals RHF)",
        "nbasis": int(mol.nao),
        "nelec": int(sum(mol.nelec)),
        "spin": int(mol.spin),
        "e_scf_ha": float(e_scf),
        "e_scf_plus_ccsd_t_ha": float(e_scf),
        "converged": bool(mf.converged),
    }


def compute_O_atom(basis: str = "cc-pvqz") -> dict:
    from pyscf import gto, scf, cc
    # 3P ground state, ROHF with degenerate-partitioned 2p occupation.
    mol = gto.Mole()
    mol.atom = "O 0 0 0"
    mol.basis = basis
    mol.spin = 2  # 3P triplet: 2 unpaired electrons
    mol.charge = 0
    mol.symmetry = False
    mol.verbose = 0
    mol.max_memory = 3000
    mol.build()
    mf = scf.ROHF(mol)
    # Use a spherically averaged 2p occupation via fractional smearing not needed;
    # PySCF ROHF with spin=2 will select an axial 3P state which is one of the
    # three degenerate components. Energy is invariant across the three.
    e_scf = mf.kernel()
    if not mf.converged:
        raise RuntimeError("O ROHF did not converge")
    mcc = cc.CCSD(mf)
    mcc.max_memory = 3000
    e_ccsd_corr, _, _ = mcc.kernel()
    if not mcc.converged:
        raise RuntimeError("O CCSD did not converge")
    e_t_corr = mcc.ccsd_t()
    e_total = e_scf + e_ccsd_corr + e_t_corr
    # For open-shell ROHF-CCSD, mcc.t1 may be a list [t1_alpha, t1_beta]; handle both cases.
    t1 = mcc.t1
    if isinstance(t1, (list, tuple)):
        flat = np.concatenate([np.asarray(a).ravel() for a in t1])
    else:
        flat = np.asarray(t1).ravel()
    diag_t1 = float(np.linalg.norm(flat) / math.sqrt(max(1, flat.size)))
    return {
        "atom": "O",
        "isotope": "16O",
        "basis": basis,
        "method": "ROHF + RCCSD(T)",
        "nbasis": int(mol.nao),
        "nelec": int(sum(mol.nelec)),
        "spin": int(mol.spin),
        "e_scf_ha": float(e_scf),
        "e_ccsd_corr_ha": float(e_ccsd_corr),
        "e_t_corr_ha": float(e_t_corr),
        "e_total_ha": float(e_total),
        "t1_diagnostic_frobenius_avg": diag_t1,
        "scf_converged": bool(mf.converged),
        "ccsd_converged": bool(mcc.converged),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--stage", choices=["frequencies", "atoms", "assemble", "all"],
                    default="all")
    args = ap.parse_args()

    ART.mkdir(parents=True, exist_ok=True)
    # Guard the frozen inputs first.
    verify_frozen_inputs()

    q_ref = json.loads(Q_REF.read_text())
    geom_A = tuple(q_ref["geometry"])                    # (r1, r2, theta) in Å, rad
    F_int = np.array(q_ref["curvature"]["matrix_internal"], float)
    E_water_ha = float(q_ref["energy"])

    result = {
        "started": datetime.datetime.now().astimezone().isoformat(timespec="seconds"),
        "declared_model": "nonrelativistic RCCSD(T), cc-pVQZ, ROHF reference for open-shell atom",
        "reference_geometry_A_A_rad": list(geom_A),
        "reference_energy_ha": E_water_ha,
        "constants": {
            "HARTREE_J": HARTREE_J, "BOHR_M": BOHR_M, "ANGSTROM_M": ANGSTROM_M,
            "U_KG": U_KG, "C_M_S": C_M_S, "NA": NA, "E_CHARGE": E_CHARGE,
            "KCAL_MOL_PER_HA": KCAL_MOL_PER_HA, "EV_PER_HA": EV_PER_HA,
            "M_H1_u": 1.00782503207, "M_O16_u": 15.99491461957,
        },
    }

    if args.stage in ("frequencies", "all"):
        freq = frequencies_cm1(F_int, geom_A, m_a=M_O16, m_b=M_H1)
        # Order/label: two stretches (~3800 cm⁻¹) and one bend (~1600 cm⁻¹).
        omega = np.array(freq["omega_cm1"])
        idx_bend = int(np.argmin(omega))
        stretch_idx = [i for i in range(3) if i != idx_bend]
        # Distinguish symmetric vs antisymmetric by stretch-vector sign of r1,r2 comps.
        classes = ["", "", ""]
        classes[idx_bend] = "bend"
        for i in stretch_idx:
            v = np.array(freq["eigenvectors_columns_in_internal_coords"])[:, i]
            classes[i] = "symmetric_stretch" if (v[0] * v[1]) > 0 else "antisymmetric_stretch"
        freq["classes"] = classes
        freq["omega_cm1_labelled"] = {classes[i]: omega[i] for i in range(3)}
        result["frequencies_wilson_gf"] = freq
        # Zero-point energy from the harmonic frequencies (for D_0 comparison).
        zpe_ha = 0.5 * sum(omega[i] * 100.0 * C_M_S * (2.0 * math.pi)  # rad/s
                           * 1.054_571_817e-34 / HARTREE_J for i in range(3))
        result["zero_point_energy_ha"] = zpe_ha

    if args.stage in ("atoms", "all"):
        pt_dir = ART / "atomic-points"
        pt_dir.mkdir(exist_ok=True)
        h_rec = compute_H_atom("cc-pvqz")
        (pt_dir / "H-cc-pvqz.json").write_text(json.dumps(h_rec, indent=2) + "\n")
        o_rec = compute_O_atom("cc-pvqz")
        (pt_dir / "O-cc-pvqz.json").write_text(json.dumps(o_rec, indent=2) + "\n")
        result["atomic_energies"] = {"H_cc-pvqz": h_rec, "O_cc-pvqz": o_rec}

    if args.stage in ("assemble", "all"):
        # Independent cross-check: our standard cc-pVQZ atomic calculations.
        h_rec = result.get("atomic_energies", {}).get("H_cc-pvqz") or json.loads(
            (ART / "atomic-points/H-cc-pvqz.json").read_text())
        o_rec = result.get("atomic_energies", {}).get("O_cc-pvqz") or json.loads(
            (ART / "atomic-points/O-cc-pvqz.json").read_text())

        # Primary: use the SAME campaign atomic basis ("Q") that the water calculation used.
        # These are frozen upstream records; consuming them keeps atoms and molecule at
        # the same basis definition. Basis composition: H (5s4p3d2f)=46 fns [aug-cc-pVQZ];
        # O (8s8p6d4f2g)=109 fns [custom augmentation of Dunning QZ family].
        campaign_records = WORKSPACE / "poams-review/artifacts/cno-correlated-2026-09-16/production/records"
        h_q_paths = list(campaign_records.glob("H-q0-L4-a1-parallel-F+0.000000-*.json"))
        o_q_paths = list(campaign_records.glob("O-q0-L4-a1-parallel-F+0.000000-*.json"))
        h_q_paths = [p for p in h_q_paths if not p.name.endswith(".energy.json")]
        o_q_paths = [p for p in o_q_paths if not p.name.endswith(".energy.json")]
        if len(h_q_paths) != 1 or len(o_q_paths) != 1:
            raise RuntimeError(f"campaign atomic Q record ambiguity: H={len(h_q_paths)} O={len(o_q_paths)}")
        h_q = json.loads(h_q_paths[0].read_text())
        o_q = json.loads(o_q_paths[0].read_text())
        E_H_Q = h_q["energies"]["ccsdt"]  # ROHF = CCSD(T) exactly for 1 electron
        E_O_Q = o_q["energies"]["ccsdt"]  # ROHF-CCSD(T) for 3P ground state
        de_ha = 2.0 * E_H_Q + E_O_Q - E_water_ha
        result["atomization"] = {
            "basis_scope": "campaign Q-level atomic basis (H aug-cc-pVQZ; O custom-augmented QZ, 109 fns); identical basis used in the water optimizer; NOT standard cc-pVQZ everywhere",
            "E_H_ha": E_H_Q,
            "E_O_ha": E_O_Q,
            "E_water_ha": E_water_ha,
            "sum_atoms_ha": 2.0 * E_H_Q + E_O_Q,
            "D_e_ha": de_ha,
            "D_e_kcal_per_mol": de_ha * KCAL_MOL_PER_HA,
            "D_e_eV": de_ha * EV_PER_HA,
            "campaign_H_record": str(h_q_paths[0].relative_to(WORKSPACE)),
            "campaign_O_record": str(o_q_paths[0].relative_to(WORKSPACE)),
            "scope": "static-nuclei electronic dissociation limit at the same finite basis and correlation level as the Q water optimizer; no ZPE, no CBS, no relativity, no core-valence beyond frozen-orbital defaults; predicted number, not an experimental accuracy claim",
        }
        # Cross-check with a standard cc-pVQZ atomic calculation (this artifact's own).
        E_H_std = h_rec["e_scf_plus_ccsd_t_ha"]
        E_O_std = o_rec["e_total_ha"]
        de_std = 2.0 * E_H_std + E_O_std - E_water_ha
        result["atomization_standard_ccpvqz_atoms_only"] = {
            "basis_scope": "standard cc-pVQZ atoms; the water energy still uses the larger campaign Q molecular basis; comparison is diagnostic only, not a like-basis atomization",
            "E_H_ha": E_H_std,
            "E_O_ha": E_O_std,
            "D_e_ha_apparent": de_std,
            "D_e_kcal_per_mol_apparent": de_std * KCAL_MOL_PER_HA,
            "scope": "diagnostic; not a like-basis atomization; do not compare directly to experiment",
        }
        # D_0 estimate using our harmonic ZPE.
        if "zero_point_energy_ha" in result:
            zpe = result["zero_point_energy_ha"]
            d0_ha = de_ha - zpe
            result["atomization"]["ZPE_ha_from_harmonic_frequencies"] = zpe
            result["atomization"]["D_0_estimate_ha"] = d0_ha
            result["atomization"]["D_0_estimate_kcal_per_mol"] = d0_ha * KCAL_MOL_PER_HA
            result["atomization"]["D_0_scope"] = "D_e minus harmonic ZPE from the same Q Hessian; anharmonic ZPE correction and post-CCSD(T)/post-QZ corrections not applied"

    result["finished"] = datetime.datetime.now().astimezone().isoformat(timespec="seconds")
    (ART / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print("wrote", ART / "result.json")


if __name__ == "__main__":
    main()
