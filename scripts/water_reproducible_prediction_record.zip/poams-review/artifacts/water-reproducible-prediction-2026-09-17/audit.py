#!/usr/bin/env python3
"""Independent audit for the water reproducible-prediction release.

Reconstructs the frequency and atomization result from the saved evidence
without touching the driver code, then requires numerical equivalence.
"""
from __future__ import annotations

import glob
import hashlib
import json
import math
from pathlib import Path

import numpy as np

WORKSPACE = Path("/Users/cfmacbook/.openclaw/workspace")
ART = WORKSPACE / "poams-review/artifacts/water-reproducible-prediction-2026-09-17"
Q_REF = WORKSPACE / "poams-review/artifacts/water-q-relaxation-2026-09-16/result.json"
Q_FREEZE = WORKSPACE / "poams-review/artifacts/water-q-relaxation-2026-09-16/freeze.json"
CAMPAIGN_RECORDS = WORKSPACE / "poams-review/artifacts/cno-correlated-2026-09-16/production/records"

# CODATA constants (must match predict.py)
HARTREE_J = 4.359_744_722_2071e-18
BOHR_M = 5.291_772_1090_3e-11
ANGSTROM_M = 1e-10
U_KG = 1.660_539_066_60e-27
C_M_S = 299_792_458.0
NA = 6.022_140_76e23
E_CHARGE = 1.602_176_634e-19
KCAL_MOL_PER_HA = HARTREE_J * NA / 4184.0
EV_PER_HA = HARTREE_J / E_CHARGE

M_H1 = 1.00782503207 * U_KG
M_O16 = 15.99491461957 * U_KG


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


checks: list[dict] = []


def record(name: str, ok: bool, detail=None):
    checks.append({"name": name, "pass": bool(ok), "detail": detail})
    if not ok:
        raise ArithmeticError(f"AUDIT FAIL: {name} — {detail}")


def main():
    # 1. Frozen upstream inputs are unchanged.
    freeze = json.loads(Q_FREEZE.read_text())
    for rel, expected in freeze["files"].items():
        p = WORKSPACE / rel
        record(f"frozen input hash matches: {rel}",
               sha256_file(p) == expected,
               {"expected": expected, "actual": sha256_file(p)})

    result = json.loads((ART / "result.json").read_text())
    q_ref = json.loads(Q_REF.read_text())

    # 2. Frequencies: independent recomputation from the same Hessian.
    r1_A, r2_A, theta = q_ref["geometry"]
    r1 = r1_A * ANGSTROM_M
    r2 = r2_A * ANGSTROM_M
    F_int_HA = np.array(q_ref["curvature"]["matrix_internal"], float)

    # Hessian in SI: convert Å→m for r indices; angle stays in rad.
    S = np.array([1.0/ANGSTROM_M, 1.0/ANGSTROM_M, 1.0])
    F_SI = HARTREE_J * (F_int_HA * np.outer(S, S))

    # G matrix from scratch (symbolic form, not copying from predict.py's G).
    ct, st = math.cos(theta), math.sin(theta)
    mH, mO = M_H1, M_O16
    G = np.zeros((3, 3))
    G[0, 0] = 1.0/mH + 1.0/mO
    G[1, 1] = 1.0/mH + 1.0/mO
    G[0, 1] = G[1, 0] = ct/mO
    G[0, 2] = G[2, 0] = -st/(mO * r2)
    G[1, 2] = G[2, 1] = -st/(mO * r1)
    G[2, 2] = (1.0/(mH*r1*r1) + 1.0/(mH*r2*r2)
               + (1.0/mO)*(1.0/(r1*r1) + 1.0/(r2*r2) - 2.0*ct/(r1*r2)))

    # An independent physical sanity check on G: the (r1,r1) diagonal is the
    # reduced mass of an OH stretch, 1/(1/mH + 1/mO). Recover μ, compare.
    mu_OH = 1.0/(1.0/mH + 1.0/mO)
    record("G(r1,r1) recovers OH reduced mass",
           abs(1.0/G[0, 0] - mu_OH) / mu_OH < 1e-12,
           {"1/G[0,0]": 1.0/G[0, 0], "reduced_mass": mu_OH})

    # G matrix agrees with predict.py's stored G.
    G_stored = np.array(result["frequencies_wilson_gf"]["G_1_kg_or_1_kg_m2"])
    record("G matrix matches driver",
           np.allclose(G, G_stored, rtol=0, atol=1e-30),
           {"max_abs_diff": float(np.max(np.abs(G - G_stored)))})

    # F matrix in SI agrees with predict.py's stored F.
    F_stored = np.array(result["frequencies_wilson_gf"]["F_SI_J_per_m2_or_rad2"])
    record("F matrix (SI) matches driver",
           np.allclose(F_SI, F_stored, rtol=1e-14, atol=1e-30),
           {"max_abs_rel_diff": float(np.max(np.abs(F_SI - F_stored) / np.maximum(1e-30, np.abs(F_stored))))})

    # Independent diagonalization of GF.
    GF = G @ F_SI
    lam = np.linalg.eigvals(GF).real
    omega_rad_s = np.sqrt(np.maximum(np.sort(lam), 0.0))
    omega_cm1_indep = omega_rad_s / (2.0 * math.pi * C_M_S * 100.0)

    omega_cm1_driver = np.array(sorted(result["frequencies_wilson_gf"]["omega_cm1"]))
    max_diff_cm1 = float(np.max(np.abs(omega_cm1_indep - omega_cm1_driver)))
    record("frequencies match driver to < 1e-6 cm^-1",
           max_diff_cm1 < 1e-6,
           {"omega_cm1_indep": omega_cm1_indep.tolist(),
            "omega_cm1_driver": omega_cm1_driver.tolist(),
            "max_abs_diff_cm1": max_diff_cm1})

    # 3. Zero-point energy from independent formula.
    hbar = 1.054_571_817e-34
    zpe_ha_indep = 0.5 * sum(omega_rad_s) * hbar / HARTREE_J
    zpe_ha_driver = float(result["zero_point_energy_ha"])
    record("ZPE matches to relative 1e-12",
           abs(zpe_ha_indep - zpe_ha_driver) / abs(zpe_ha_driver) < 1e-12,
           {"indep": zpe_ha_indep, "driver": zpe_ha_driver,
            "rel_diff": abs(zpe_ha_indep - zpe_ha_driver) / abs(zpe_ha_driver)})

    # 4. Atomic Q energies: re-read the frozen campaign records, hash them,
    # and recompute atomization independently.
    h_paths = [p for p in CAMPAIGN_RECORDS.glob("H-q0-L4-a1-parallel-F+0.000000-*.json")
               if not p.name.endswith(".energy.json")]
    o_paths = [p for p in CAMPAIGN_RECORDS.glob("O-q0-L4-a1-parallel-F+0.000000-*.json")
               if not p.name.endswith(".energy.json")]
    record("unique H Q record found", len(h_paths) == 1, {"count": len(h_paths)})
    record("unique O Q record found", len(o_paths) == 1, {"count": len(o_paths)})

    # Compare hashes against Q freeze list.
    h_hash_expected = freeze["files"][str(h_paths[0].relative_to(WORKSPACE))]
    o_hash_expected = freeze["files"][str(o_paths[0].relative_to(WORKSPACE))]
    record("H Q record hash unchanged", sha256_file(h_paths[0]) == h_hash_expected)
    record("O Q record hash unchanged", sha256_file(o_paths[0]) == o_hash_expected)

    h_q = json.loads(h_paths[0].read_text())
    o_q = json.loads(o_paths[0].read_text())
    E_H = h_q["energies"]["ccsdt"]
    E_O = o_q["energies"]["ccsdt"]
    E_water = float(q_ref["energy"])

    # For the H atom: ROHF == CCSD == CCSD(T) exactly (single electron).
    record("H CCSD(T) equals RHF (1 electron)",
           abs(h_q["energies"]["ccsdt"] - h_q["energies"]["reference"]) < 1e-14,
           {"reference": h_q["energies"]["reference"],
            "ccsd": h_q["energies"]["ccsd"],
            "ccsdt": h_q["energies"]["ccsdt"]})

    # O CCSD(T) internal consistency: reference + CCSD_corr + (T)_corr should
    # reconstruct ccsdt.
    ccsd_corr = o_q["energies"]["ccsd"] - o_q["energies"]["reference"]
    t_corr = o_q["energies"].get("triples", o_q["energies"]["ccsdt"] - o_q["energies"]["ccsd"])
    ccsdt_check = o_q["energies"]["reference"] + ccsd_corr + t_corr
    record("O CCSD(T) sum consistency",
           abs(ccsdt_check - o_q["energies"]["ccsdt"]) < 1e-11,
           {"ccsdt_stored": o_q["energies"]["ccsdt"], "ccsdt_reconstructed": ccsdt_check})

    de_ha = 2.0 * E_H + E_O - E_water
    de_kcal = de_ha * KCAL_MOL_PER_HA
    de_ev = de_ha * EV_PER_HA

    driver_atm = result["atomization"]
    record("D_e (Ha) matches driver to < 1e-12",
           abs(de_ha - driver_atm["D_e_ha"]) < 1e-12,
           {"indep": de_ha, "driver": driver_atm["D_e_ha"]})
    record("D_e (kcal/mol) matches driver to < 1e-9",
           abs(de_kcal - driver_atm["D_e_kcal_per_mol"]) < 1e-9,
           {"indep": de_kcal, "driver": driver_atm["D_e_kcal_per_mol"]})
    record("D_e (eV) matches driver to < 1e-9",
           abs(de_ev - driver_atm["D_e_eV"]) < 1e-9,
           {"indep": de_ev, "driver": driver_atm["D_e_eV"]})

    # D_0 with harmonic ZPE
    d0_ha = de_ha - zpe_ha_indep
    d0_kcal = d0_ha * KCAL_MOL_PER_HA
    record("D_0 estimate matches driver to < 1e-9",
           abs(d0_kcal - driver_atm["D_0_estimate_kcal_per_mol"]) < 1e-9,
           {"indep": d0_kcal, "driver": driver_atm["D_0_estimate_kcal_per_mol"]})

    # 5. Registration file present and non-empty.
    reg = ART / "registration.md"
    record("registration file present", reg.exists() and reg.stat().st_size > 500)

    # 6. The atomic-points/ H and O JSON files this run wrote (standard cc-pVQZ)
    # exist and their energies match what the driver's diagnostic block stored.
    h_std = json.loads((ART / "atomic-points/H-cc-pvqz.json").read_text())
    o_std = json.loads((ART / "atomic-points/O-cc-pvqz.json").read_text())
    diag = result.get("atomization_standard_ccpvqz_atoms_only", {})
    record("std cc-pVQZ H matches driver value",
           abs(h_std["e_scf_ha"] - diag["E_H_ha"]) < 1e-12)
    record("std cc-pVQZ O matches driver value",
           abs(o_std["e_total_ha"] - diag["E_O_ha"]) < 1e-12)

    # H atom in standard cc-pVQZ should still be close to −0.5 Ha (basis limit).
    record("std cc-pVQZ H within 200 μHa of −0.5",
           abs(h_std["e_scf_ha"] + 0.5) < 2e-4,
           {"E_H": h_std["e_scf_ha"], "deviation_from_half_hartree": h_std["e_scf_ha"] + 0.5})

    # 7. Total-file-count sanity for the atomic points directory.
    n_atomic_points = len(list((ART / "atomic-points").glob("*.json")))
    record("atomic-points has 2 records (H + O)", n_atomic_points == 2, {"count": n_atomic_points})

    # 8. Wilson G matrix G(θ,θ) reduces correctly at the near-symmetric geometry
    # (r1 ≈ r2 to a few ppb). Closed form for exact symmetry, compare within
    # the geometry's own asymmetry level.
    if abs(r1 - r2) / r1 < 1e-6:
        r = 0.5 * (r1 + r2)
        G_tt_symmetric_expected = (2.0/(mH*r*r)) + (2.0/(mO*r*r))*(1.0 - ct)
        rel_diff = abs(G[2, 2] - G_tt_symmetric_expected) / abs(G_tt_symmetric_expected)
        record("G(θ,θ) equals symmetric-case closed form to relative geometry asymmetry (r1≈r2)",
               rel_diff < 1e-6,
               {"stored": G[2, 2], "closed_form": G_tt_symmetric_expected,
                "rel_diff": rel_diff, "r1_r2_rel_asymmetry": abs(r1 - r2) / r1})

    n = len(checks)
    passed = sum(1 for c in checks if c["pass"])
    audit = {"passed": passed == n, "n_checks": n, "n_pass": passed,
             "checks": checks}
    (ART / "audit.json").write_text(json.dumps(audit, indent=2) + "\n")
    print(f"AUDIT: {passed}/{n} checks passed")


if __name__ == "__main__":
    main()
