# Water reproducible-prediction registration — 17 Sep 2026

## Scope

Close the water demonstration with two non-empirical, method-limited predictions of the same declared model that produced the T and Q geometries:

1. **Harmonic vibrational frequencies** of the three internal coordinates at the Q equilibrium. Wilson GF matrix method applied to the internal Hessian already stored in the Q reference result (physical units, cross terms included). No new potential-energy calculation.
2. **Static-nuclei atomization energy** D_e = 2·E(H) + E(O) − E(H₂O)_Q at Q basis. New atomic calculations for H (¹H, cc-pVQZ, RHF = FCI for 1 electron) and O (¹⁶O, ³P ground state, cc-pVQZ, ROHF + RCCSD(T)).

## What the predictions do and do not assert

- The reference model is nonrelativistic RCCSD(T) with the conventional pair operator; adopted alpha calibration; no density fitting or frozen core; no empirical geometry, frequency, or energy input to any calculation in this release.
- Frequencies are **harmonic**, static-nuclei, single-electronic-state. They are not corrected for anharmonicity, vibrational-rotational coupling, or non-Born–Oppenheimer effects.
- D_e is a **static-nuclei electronic** dissociation limit at cc-pVQZ. It is not corrected for zero-point vibrational energy, core-valence correlation beyond frozen-orbital defaults, higher-order correlation, relativity, or basis-set incompleteness.
- These are **finite-basis, finite-order** predictions at a specific, published methodological standard. Any comparison to experiment is a fitness-for-purpose check on the method, not a validation of experimental accuracy.

## Frozen upstream inputs

- The Q reference result and its complete audit (bounded_Q_equilibrium_reference_complete, 632 checks passed).
- The Q run's freeze.json and all 31 upstream files it fixed.
- The published exhibit files at commit 857c5d5.

## Numerical protocol

### Frequencies
- Internal coordinates: (r₁, r₂, θ), same as the Q optimizer used.
- G matrix: standard Wilson result for a symmetric AB₂ molecule, evaluated at the Q equilibrium.
- F matrix: physical-unit Hessian from `curvature.matrix_internal` in the Q result JSON.
- Diagonalize GF; report ω = √λ in cm⁻¹.
- Isotopes: ¹H (1.00782503207 u) and ¹⁶O (15.99491461957 u). Both are the ground natural-abundance isotopes in the sample water experiments this will be compared to.

### Atomic Q energies
- H: cc-pVQZ, RHF, spherical, unrestricted for symmetry (1 electron; RHF = ROHF = UHF here).
- O: cc-pVQZ, ROHF-CCSD(T), ³P ground state, spherical (equally distributed 2p occupation), no frozen core.
- Same PySCF stack, same integrals treatment, and same one-thread setup as the Q molecular run.

### Independent audit
- Recompute Wilson G elements symbolically vs numerically.
- Recompute frequencies from an independent finite-difference of the G·F product.
- Reload atomic checkpoints and reproduce RHF and CCSD(T) energies via a separate driver.
- Sanity-check: rederive D_e in kcal/mol, eV and Ha from the same three energies; require all three to be consistent to double-precision round-off.
- Verify all frozen upstream file hashes are unchanged.

## Bounds

- Wall time: ≤ 30 minutes on one BLAS thread.
- Distinct energy evaluations: ≤ 6 (H spherical setup + O ROHF-CCSD(T) + O(T) reference).
- No optimizer runs; no geometry changes.
- No dependence on OAuth or external services; pure local CPU.
