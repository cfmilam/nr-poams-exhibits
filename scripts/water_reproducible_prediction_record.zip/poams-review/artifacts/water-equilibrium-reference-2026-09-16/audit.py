#!/usr/bin/env python3
"""Independent read-only finite-space equilibrium and custody audit."""
from pathlib import Path
from decimal import Decimal,localcontext
import hashlib,json,math
import numpy as np
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
checks=[]
def check(name,ok,value=None):checks.append({'check':name,'pass':bool(ok),'value':value})
def main():
    result=read(HERE/'result.json');freeze=read(HERE/'freeze.json')
    for p,h in freeze['files'].items():check('frozen '+p,sha(ROOT/p)==h)
    rows=[read(p) for p in HERE.glob('p-*.json')]
    def find(label,q):
        found=[r for r in rows if r['basis']==label and np.max(abs(np.array(r['geometry'])-q))<1e-13]
        if len(found)!=1:raise AssertionError('ambiguous or absent '+label+' '+str(q))
        return found[0]
    q=np.array(result['geometry']);h=np.array(freeze['gradient_steps']);start=np.array(freeze['start']);scale=np.array(freeze['scales'])
    check('completed',read(HERE/'status.json')['state']=='completed')
    check('no fitted geometry start',np.array_equal(start,result['start_geometry']))
    for r in rows:
        check(r['basis']+' state complete',r['complete'])
        check(r['basis']+' convergence',r['cc_diagnostics']['amplitude_update_norm']<2e-8)
        check(r['basis']+' metric',r['metric']['final_orbital_metric_defect']<1e-8)
        check(r['basis']+' seed',r['metric']['seed_containment_defect']<1e-9)
        check(r['basis']+' pair control',abs(r['pair_check']['library_difference'])<1e-8)
    energy=lambda label,x:Decimal(str(find(label,x)['CCSD(T)']))
    def grad(label,x,steps):
        vals=[]
        with localcontext() as ctx:
            ctx.prec=45
            for i,s in enumerate(steps):
                v=np.zeros(3);v[i]=s
                vals.append(float((energy(label,x+v)-energy(label,x-v))/(2*Decimal(str(s)))))
        return np.array(vals)
    full=grad('T',q,h);half=grad('T',q,h/2);g=(4*half-full)/3
    check('independent three-coordinate gradient',max(abs(g-np.array(result['gradient'])))<1e-9,g.tolist())
    check('stationary',max(abs(g))<2e-5)
    check('step convergence',max(abs(full-half))<5e-6)
    e0=float(energy('T',q));estart=float(energy('T',start))
    check('energy decreases',e0<estart)
    check('energy difference',abs(e0-estart-result['energy_change_from_start'])<1e-10)
    check('reported angle',abs(math.degrees(q[2])-result['angle_degrees'])<1e-10)
    hh=np.array(result['curvature']['steps']);mat=np.zeros((3,3))
    for i in range(3):
        v=np.zeros(3);v[i]=hh[i]
        mat[i,i]=float(energy('T',q+v)+energy('T',q-v)-2*energy('T',q))/hh[i]**2
        for j in range(i):
            w=np.zeros(3);w[j]=hh[j]
            mat[i,j]=mat[j,i]=float(energy('T',q+v+w)-energy('T',q+v-w)-energy('T',q-v+w)+energy('T',q-v-w))/(4*hh[i]*hh[j])
    check('independent Hessian',max(abs(mat-np.array(result['curvature']['matrix_internal'])).flat)<1e-7)
    eig=np.linalg.eigvalsh(mat*scale[:,None]*scale[None,:])
    check('all three local modes positive',min(eig)>1e-4,eig.tolist())
    for label,reported in result['basis_checks'].items():
        gb=grad(label,q,h)
        check(label+' independent basis gradient',max(abs(gb-reported['gradient_at_T_minimum']))<1e-9)
        estimate=np.linalg.solve(mat,-gb)
        check(label+' displacement estimate labeled only',max(abs(estimate-reported['local_displacement_estimate']))<1e-7)
    final=read(HERE/'final-center.json')
    check('final state custody',sha(HERE/final['state_file'])==final['state_sha256'])
    check('final reference stable',all(final['rhf_stability'].values()))
    z=np.load(HERE/final['state_file'],allow_pickle=False)
    metric=z['mo_coeff'].T@z['overlap']@z['mo_coeff']
    check('final normalization',np.linalg.norm(metric-np.eye(len(metric)),2)<1e-8)
    check('final entry count',abs(np.einsum('ij,ji',z['density'],z['overlap'])-10)<1e-8)
    check('same objective at final check',abs(final['CCSD(T)']-e0)<1e-8)
    output={'passed':all(c['pass'] for c in checks),'count':len(checks),'checks':checks,
            'failures':[c for c in checks if not c['pass']]}
    (HERE/'audit.json').write_text(json.dumps(output,indent=2)+'\n')
    print(json.dumps({k:output[k] for k in ('passed','count','failures')}))
    if not output['passed']:raise SystemExit(1)
if __name__=='__main__':main()
