#!/usr/bin/env python3
"""Separately gated three-coordinate finite-space equilibrium reference."""
import os
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS'):os.environ[k]='1'
from pathlib import Path
import datetime,hashlib,importlib.util,json,math,signal,sys,time
import numpy as np
from scipy.optimize import minimize
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
PRE=ROOT/'poams-review/artifacts/water-correlation-basis-2026-09-16'
REG=ROOT/'poams-review/reviews/water-equilibrium-reference-registration-2026-09-16.md'
s=importlib.util.spec_from_file_location('comparison',PRE/'campaign.py');c=importlib.util.module_from_spec(s);s.loader.exec_module(c)
c.HERE=HERE;c.m.HERE=HERE
SCALE=np.array([.05,.05,.2]);H=np.array([.0002,.0002,.0004])
Q0=c.m.Q.copy();cache={};trajectory=[]

def energy(q,label='T'):
    q=np.asarray(q);key=(label,tuple(q))
    if key not in cache:
        ident=hashlib.sha256((label+json.dumps(q.tolist())).encode()).hexdigest()[:18]
        r=c.solve(label,q,'p-'+label+'-'+ident)
        cache[key]=r
        c.require(len(cache)<=200,'registered evaluation cap')
    return cache[key]['CCSD(T)']

def gradient(q,label='T',steps=H):
    out=[]
    for i,h in enumerate(steps):
        v=np.zeros(3);v[i]=h
        out.append((energy(q+v,label)-energy(q-v,label))/(2*h))
    return np.array(out)

def objective(x):
    q=Q0+SCALE*x;e=energy(q);g=gradient(q)
    row={'geometry':q.tolist(),'energy':e,'gradient':g.tolist(),'max_abs_gradient':float(max(abs(g)))}
    trajectory.append(row);c.dump('trajectory.json',trajectory);c.emit('OBJECTIVE',**row)
    return e,g*SCALE

def hessian(q):
    h=np.array([.002,.002,.004]);e=energy(q);mat=np.zeros((3,3));diag_half=[]
    for i in range(3):
        v=np.zeros(3);v[i]=h[i]
        mat[i,i]=(energy(q+v)+energy(q-v)-2*e)/h[i]**2
        diag_half.append((energy(q+v/2)+energy(q-v/2)-2*e)/(h[i]/2)**2)
        for j in range(i):
            w=np.zeros(3);w[j]=h[j]
            mat[i,j]=mat[j,i]=(energy(q+v+w)-energy(q+v-w)-energy(q-v+w)+energy(q-v-w))/(4*h[i]*h[j])
    scaled=SCALE[:,None]*mat*SCALE[None,:];vals=np.linalg.eigvalsh(scaled)
    c.require(min(vals)>1e-4,'nonpositive or unresolved internal curvature')
    c.require(max(abs(np.diag(mat)-diag_half))<.002,'diagonal Hessian step check')
    return {'matrix_internal':mat.tolist(),'scaled_eigenvalues':vals.tolist(),
            'coordinate_scales':SCALE.tolist(),'steps':h.tolist(),'half_step_diagonal':diag_half,
            'scope':'positive internal curvature, not vibrational frequencies'}

def run():
    compare=json.loads((PRE/'result.json').read_text());audit=json.loads((PRE/'audit.json').read_text())
    c.require(compare['bounded_optimization_justified'] and audit['passed'],'comparison gate not satisfied')
    c.require(REG.exists(),'separate registration missing')
    frozen=json.loads((PRE/'freeze.json').read_text())['files'].copy()
    for p in (Path(__file__),REG,PRE/'result.json',PRE/'audit.json'):frozen[str(p.relative_to(ROOT))]=c.digest(p)
    if (HERE/'freeze.json').exists():c.require(json.loads((HERE/'freeze.json').read_text())['files']==frozen,'restart source mismatch')
    else:c.dump('freeze.json',{'files':frozen,'start':Q0.tolist(),'scales':SCALE.tolist(),'gradient_steps':H.tolist(),
             'registered':datetime.datetime.now().astimezone().isoformat()})
    c.dump('status.json',{'state':'running','pid':os.getpid(),'wall_cap_seconds':7200})
    signal.signal(signal.SIGALRM,lambda *args: (_ for _ in ()).throw(TimeoutError('registered two-hour cap')));signal.alarm(7200)
    # Relative search box only, with no observed geometry/energy targets.
    bounds=[(-3.,3.),(-3.,3.),(-1.75,1.75)]
    res=minimize(objective,np.zeros(3),jac=True,method='L-BFGS-B',bounds=bounds,
                 options={'maxiter':20,'maxls':8,'ftol':1e-13,'gtol':1e-7})
    q=Q0+SCALE*res.x
    c.require(res.success,'optimizer did not converge: '+str(res.message))
    c.require(all(lo+.01<x<hi-.01 for x,(lo,hi) in zip(res.x,bounds)),'boundary minimum')
    g1=gradient(q);g2=gradient(q,steps=H/2);gr=(4*g2-g1)/3
    c.require(max(abs(gr))<2e-5,'final three-coordinate stationarity')
    c.require(max(abs(g1-g2))<5e-6,'final derivative step check')
    centre=c.solve('T',q,'final-center',analytic=True,stability=True)
    hs=hessian(q)
    # Exact symmetry operation is a check, never an imposed coordinate reduction.
    swapped=q[[1,0,2]];symmetry_error=energy(swapped)-energy(q)
    c.require(abs(symmetry_error)<1e-8,'endpoint permutation')
    # Finite-space uncertainty diagnostic at this geometry; no Q relaxation yet.
    basis={}
    for label in ('Q','T-tail'):
        e=energy(q,label);g=gradient(q,label)
        basis[label]={'energy':e,'gradient_at_T_minimum':g.tolist(),
                     'local_displacement_estimate':np.linalg.solve(np.array(hs['matrix_internal']),-g).tolist(),
                     'scope':'unrelaxed basis check; Newton displacement is an estimate, not an equilibrium'}
    c.require(all(c.digest(ROOT/p)==h for p,h in frozen.items()),'input mutation')
    result={'status':'bounded_T_equilibrium_reference_complete','basis':'T','method':'all-entry RCCSD(T)',
       'geometry':q.tolist(),'distances_angstrom':q[:2].tolist(),'angle_degrees':float(math.degrees(q[2])),
       'start_geometry':Q0.tolist(),'energy':energy(q),'energy_change_from_start':energy(q)-energy(Q0),
       'gradient':gr.tolist(),'gradient_step_difference':(g1-g2).tolist(),'curvature':hs,
       'endpoint_energy_difference':symmetry_error,'basis_checks':basis,
       'optimization':{'success':bool(res.success),'message':str(res.message),'iterations':res.nit,'evaluations':res.nfev},
       'unique_points':len(cache),'limitations':[
          'A local finite-T-basis effective-model minimum, not an independent native-closure derivation.',
          'Q and diffuse checks are unrelaxed; basis-limit geometry is not established.',
          'No full triples/quadruples, recoil, relativistic or nuclear-motion corrections.',
          'Previous native water failure, methane partial and s/p-seed failure remain.',
          'Atomic O axial 1.018046% sensitivity and removal limits retained; no ad hoc error transfer or energy addition.',
          'No dissociation, atomization energy or experimental-accuracy qualification.']}
    c.dump('result.json',result);c.dump('status.json',{'state':'completed','pid':os.getpid()});c.emit('COMPLETE',geometry=q.tolist(),angle_degrees=result['angle_degrees'])

if __name__=='__main__':
    try:run()
    except Exception as exc:
        c.dump('status.json',{'state':'stopped_failure','pid':os.getpid(),'error':repr(exc)});c.emit('STOPPED_FAILURE',error=repr(exc));raise
