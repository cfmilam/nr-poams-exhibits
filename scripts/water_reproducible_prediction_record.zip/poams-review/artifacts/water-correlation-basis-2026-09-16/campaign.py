#!/usr/bin/env python3
"""Registered, checkpointed full-space water correlation/basis gate."""
import os
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS'):
    os.environ[k]='1'
from pathlib import Path
import datetime, hashlib, importlib.util, json, math, signal, sys, time
import numpy as np
from pyscf import cc, mp, lib, scf
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
SOURCE=ROOT/'poams-review/artifacts/molecular-reentry-2026-09-16/preflight.py'
REG=ROOT/'poams-review/reviews/water-correlation-basis-registration-2026-09-16.md'
s=importlib.util.spec_from_file_location('reentry',SOURCE)
m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
m.HERE=HERE
for el in ('H','O'):m.SOURCES[(el,4,1)]=m.load_atom(el,4,1)
m.CONFIGS={'D':(2,1,False),'T':(3,1,False),'Q':(4,1,False),'T-tail':(3,3,False)}
lib.num_threads(1)
require=m.require
dump=m.dump
digest=m.digest
emit=m.emit
METHODS=('RHF','MP2','CCSD','CCSD(T)')

def internal_grad(cart,q):
    a,b,t=q
    return np.array([cart[1,0]/m.A_ANG,
                     (cart[2,0]*math.cos(t)+cart[2,1]*math.sin(t))/m.A_ANG,
                     b*(-cart[2,0]*math.sin(t)+cart[2,1]*math.cos(t))/m.A_ANG])

def solve(label,q,tag,analytic=False,override=None,shift=0.,ucc_check=False,stability=False):
    path=HERE/(tag+'.json')
    if path.exists():
        r=json.loads(path.read_text())
        require(r['complete'] and r['basis']==label and np.array_equal(q,r['geometry']), 'checkpoint mismatch')
        return r
    start=time.monotonic();mol=m.make(label,q,override)
    mf,overlap,x,cert=m.configure(mol,tag)
    dm,seed=m.atomic_seed(mol,label) if override is None else (None,None)
    if seed is not None:
        cert['seed_containment_defect']=float(np.linalg.norm(seed-x@(x.T@overlap@seed)))
        require(cert['seed_containment_defect']<1e-9,'seed containment')
    if shift:
        h=mf.get_hcore()+shift*overlap;mf.get_hcore=lambda *args:h
    ehf=float(mf.kernel(dm0=dm));gn=float(np.linalg.norm(mf.get_grad(mf.mo_coeff,mf.mo_occ)))
    require(mf.converged and gn<1e-7,'RHF stationarity')
    cert['final_orbital_metric_defect']=float(np.linalg.norm(mf.mo_coeff.T@overlap@mf.mo_coeff-np.eye(mol.nao),2))
    require(cert['final_orbital_metric_defect']<1e-8,'orbital metric')
    p=mp.MP2(mf);p.max_memory=3000;pe=p.ao2mo();emp,_=p.kernel(eris=pe,with_t2=False)
    g=np.asarray(pe.ovov).reshape(p.nocc,p.nmo-p.nocc,p.nocc,p.nmo-p.nocc).transpose(0,2,1,3)
    pair=m.pair.cofactor_second_order(g,mf.mo_energy[:p.nocc],mf.mo_energy[p.nocc:])
    pair['library_difference']=float(pair['energy']-emp)
    require(abs(pair['library_difference'])<1e-8 and pair['perturbative_readiness'],'MP2 independent pair control')
    c=cc.CCSD(mf);c.max_memory=3000;c.conv_tol=1e-11;c.conv_tol_normt=1e-9;c.max_cycle=100
    eris=c.ao2mo();ec,t1,t2=c.kernel(eris=eris)
    require(c.converged,'CCSD convergence')
    u1,u2=c.update_amps(t1,t2,eris)
    residual=float(np.linalg.norm(c.amplitudes_to_vector(u1-t1,u2-t2)))
    require(residual<2e-8,'CCSD extra-update residual')
    et=float(c.ccsd_t(eris=eris))
    diag={'t1':float(c.get_t1_diagnostic()),'d1':float(c.get_d1_diagnostic()),
          'd2':float(c.get_d2_diagnostic()),'amplitude_update_norm':residual,
          'max_t1':float(np.max(abs(t1))),'max_t2':float(np.max(abs(t2))),
          'gap':float(mf.mo_energy[p.nocc]-mf.mo_energy[p.nocc-1])}
    require(diag['gap']>0 and diag['t1']<.02 and diag['d1']<.05,'single-reference screening')
    row={'complete':True,'basis':label,'geometry':np.array(q).tolist(),'nao':mol.nao,
         'RHF':ehf,'MP2':float(ehf+emp),'CCSD':float(ehf+ec),'CCSD(T)':float(ehf+ec+et),
         'triples':et,'cc_diagnostics':diag,'metric':cert,'pair_check':pair,'scf_gradient_norm':gn,
         'method':'all-entry direct-integral closed-shell RCCSD(T), nonrelativistic point compacts',
         'source_sha256':digest(Path(__file__))}
    if analytic:
        row['analytic_gradients']={}
        c.solve_lambda(eris=eris);require(c.converged_lambda,'CCSD Lambda convergence')
        for method,obj in [('RHF',mf),('CCSD',c)]:
            cart=obj.nuc_grad_method().kernel()
            row['analytic_gradients'][method]={'cartesian':cart.tolist(),'internal':internal_grad(cart,q).tolist(),
                  'translation_residual':float(np.linalg.norm(cart.sum(axis=0)))}
        dens=c.make_rdm1();row['cc_density_trace']=float(np.trace(dens))
        require(abs(row['cc_density_trace']-10)<1e-7,'CC density count')
    if stability:
        _,_,si,se=mf.stability(internal=True,external=True,return_status=True,verbose=0)
        row['rhf_stability']={'internal':bool(si),'external':bool(se)}
        require(si and se,'RHF stability')
    if ucc_check:
        u=cc.UCCSD(mf.to_uhf());u.max_memory=3000;u.conv_tol=1e-11;u.conv_tol_normt=1e-9;u.max_cycle=100
        ue=u.ao2mo();uec,_,_=u.kernel(eris=ue);require(u.converged,'UCC closed shell control')
        ut=float(u.ccsd_t(eris=ue))
        row['ucc_difference']={'CCSD':float(ehf+uec-row['CCSD']),'CCSD(T)':float(ehf+uec+ut-row['CCSD(T)'])}
        require(max(abs(v) for v in row['ucc_difference'].values())<1e-7,'RCC/UCC disagreement')
    if analytic or tag.endswith('-center'):
        state=HERE/(tag+'.npz')
        np.savez_compressed(state,overlap=overlap,x=x,mo_coeff=mf.mo_coeff,mo_occ=mf.mo_occ,
                            mo_energy=mf.mo_energy,density=mf.make_rdm1(),t1=t1,t2=t2)
        row['state_file']=state.name;row['state_sha256']=digest(state)
    row['seconds']=time.monotonic()-start;dump(tag+'.json',row)
    emit('POINT',tag=tag,nao=mol.nao,CCSD_T=row['CCSD(T)'],seconds=row['seconds'])
    return row

def freeze():
    files=[Path(__file__),REG,SOURCE,m.PROBE,m.OLD]
    for src in m.SOURCES.values():files.extend([src['path'],src['statepath']])
    frozen={str(p.relative_to(ROOT)):digest(p) for p in files}
    if (HERE/'freeze.json').exists():
        require(json.loads((HERE/'freeze.json').read_text())['files']==frozen,'input/source freeze mismatch')
    else:
        dump('freeze.json',{'time':datetime.datetime.now().astimezone().isoformat(),'files':frozen,
             'geometry':m.Q.tolist(),'configs':m.CONFIGS,'python':sys.version,'pyscf':lib.__package__})
    return frozen

def stencil(rows,h,method):
    e={k:r[method] for k,r in rows.items()}
    g1=(e[1]-e[-1])/(2*h);g2=(e[2]-e[-2])/(4*h)
    h1=(e[1]+e[-1]-2*e[0])/h**2;h2=(e[2]+e[-2]-2*e[0])/(4*h**2)
    return {'slope':(4*g1-g2)/3,'step_discrepancy':abs(g1-g2),
            'curvature':(4*h1-h2)/3,'curvature_step_discrepancy':abs(h1-h2)}

def run():
    frozen=freeze();dump('status.json',{'state':'running','pid':os.getpid(),'wall_cap_seconds':7200})
    signal.signal(signal.SIGALRM,lambda *args: (_ for _ in ()).throw(TimeoutError('registered wall cap')));signal.alarm(7200)
    if not (HERE/'atomic-controls.json').exists():dump('atomic-controls.json',{'controls':m.atomic_controls()})
    allrows={};slopes={}
    for label in ('D','T','Q','T-tail'):
        rows={}
        for step in (0,-1,1,-2,2):
            q=m.Q.copy();q[2]+=math.radians(.5*step)
            tag=f'{label}-center' if step==0 else f'{label}-angle-{step:+d}'
            rows[step]=solve(label,q,tag,analytic=step==0 and label in ('T','Q'),
                    ucc_check=label=='D' and step==0,stability=label=='T' and step==0)
        allrows[label]=rows
        slopes[label]={'angle':{meth:stencil(rows,math.radians(.5),meth) for meth in METHODS}}
        if label in ('T','Q'):
            rad={0:rows[0]}
            for step in (-1,1,-2,2):
                q=m.Q.copy();q[:2]+=.002*step
                rad[step]=solve(label,q,f'{label}-stretch-{step:+d}')
            slopes[label]['symmetric_stretch']={meth:stencil(rad,.002,meth) for meth in METHODS}
            for meth in ('RHF','CCSD'):
                gr=rows[0]['analytic_gradients'][meth]['internal']
                for coord,exact in [('angle',gr[2]),('symmetric_stretch',sum(gr[:2]))]:
                    error=exact-slopes[label][coord][meth]['slope']
                    slopes[label][coord][meth]['analytic_minus_stencil']=error
                    require(abs(error)<2e-5,'analytic derivative check')
        dump('slopes-in-progress.json',slopes)
    theta=.47;rot=np.array([[math.cos(theta),0,math.sin(theta)],[0,1,0],[-math.sin(theta),0,math.cos(theta)]])
    xyz=[(el,tuple(np.array(x)@rot+[.31,-.22,.18])) for el,x in m.atoms(m.Q)]
    moved=solve('T',m.Q,'T-rigid-permuted',override=[xyz[i] for i in (2,0,1)])
    shifted=solve('D',m.Q,'D-shifted',shift=100.)
    controls={'rigid_permutation':{meth:moved[meth]-allrows['T'][0][meth] for meth in METHODS},
              'energy_zero':{meth:shifted[meth]-1000-allrows['D'][0][meth] for meth in METHODS}}
    require(max(abs(v) for d in controls.values() for v in d.values())<1e-7,'covariance/energy zero')
    gates=[]
    for coord in ('angle','symmetric_stretch'):
        t=slopes['T'][coord]['CCSD(T)'];q=slopes['Q'][coord]['CCSD(T)']
        gates.append({'name':coord+' T/Q sensitivity','pass':abs(q['slope']-t['slope'])<max(.25*abs(q['slope']),2e-4),
                      'difference':q['slope']-t['slope']})
        for label in ('T','Q'):
            full=slopes[label][coord]['CCSD(T)'];base=slopes[label][coord]['CCSD']
            gates.append({'name':label+' '+coord+' triples sensitivity',
                    'pass':abs(full['slope']-base['slope'])<max(.25*abs(full['slope']),2e-4),
                    'difference':full['slope']-base['slope']})
    ts=[slopes[k]['angle']['CCSD(T)'] for k in ('T','Q','T-tail')]
    gates.append({'name':'resolved common angular descent','pass':all(t['slope']>10*max(t['step_discrepancy'],2e-5) for t in ts) or all(t['slope']<-10*max(t['step_discrepancy'],2e-5) for t in ts)})
    require(all(digest(ROOT/p)==h for p,h in frozen.items()),'input mutation')
    result={'status':'fixed_geometry_comparison_complete','slopes':slopes,'controls':controls,'staging_gates':gates,
         'bounded_optimization_justified':all(g['pass'] for g in gates),'point_count':30,
         'scope':'Local-descent staging only; no equilibrium, basis-limit or experimental accuracy claim.'}
    dump('result.json',result);dump('status.json',{'state':'completed','pid':os.getpid()});emit('COMPLETE',gates=gates)

if __name__=='__main__':
    try:run()
    except Exception as exc:
        dump('status.json',{'state':'stopped_failure','pid':os.getpid(),'error':repr(exc)});emit('STOPPED_FAILURE',error=repr(exc));raise
